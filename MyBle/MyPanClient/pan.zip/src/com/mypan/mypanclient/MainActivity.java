package com.mypan.mypanclient;

import android.Manifest;
import android.app.ActionBar;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    EditText etServer, etKey, etTether;
    Button btnConnect, btnDisconnect, btnCopy, btnClear;
    TextView tvInfo, tvBatt, tvPan, tvResult;

    PanService svc;
    boolean bound = false;
    boolean pendingConnect = false;

    final PanService.Ui ui = new PanService.Ui() {
        @Override public void onInfo(final String s) { runOnUiThread(new Runnable() { public void run() { tvInfo.setText(s); } }); }
        @Override public void onBatt(final String s) { runOnUiThread(new Runnable() { public void run() {
            tvBatt.setText(s); tvBatt.setVisibility(s == null || s.length() == 0 ? View.GONE : View.VISIBLE);
        } }); }
        @Override public void onPan(final String s) { runOnUiThread(new Runnable() { public void run() { tvPan.setText(s); } }); }
        @Override public void onLog(final String s) { runOnUiThread(new Runnable() { public void run() { tvResult.append(s); } }); }
        @Override public void onLogReset(final String s) { runOnUiThread(new Runnable() { public void run() { tvResult.setText(s); } }); }
        @Override public void onBtn(final String text, final boolean enabled) { runOnUiThread(new Runnable() { public void run() {
            btnConnect.setText(text); btnConnect.setEnabled(enabled);
        } }); }
        @Override public void onDisconnectBtn(final boolean enabled) { runOnUiThread(new Runnable() { public void run() { btnDisconnect.setEnabled(enabled); } }); }
        @Override public void onToast(final String s) { runOnUiThread(new Runnable() { public void run() { Toast.makeText(MainActivity.this, s, Toast.LENGTH_SHORT).show(); } }); }
    };

    final ServiceConnection conn = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName n, IBinder b) {
            svc = ((PanService.LocalBinder) b).getService();
            svc.setUi(ui);
            svc.ensureAutoConnect();
        }
        @Override public void onServiceDisconnected(ComponentName n) { svc = null; }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        etServer  = (EditText) findViewById(R.id.et_server);
        etKey    = (EditText) findViewById(R.id.et_key);
        etTether = (EditText) findViewById(R.id.et_tether);
        btnConnect = (Button) findViewById(R.id.btn_connect);
        btnDisconnect = (Button) findViewById(R.id.btn_disconnect);
        btnCopy = (Button) findViewById(R.id.btn_copy);
        btnClear = (Button) findViewById(R.id.btn_clear);
        tvInfo = (TextView) findViewById(R.id.tv_info);
        tvBatt = (TextView) findViewById(R.id.tv_batt);
        tvPan  = (TextView) findViewById(R.id.tv_pan);
        tvResult = (TextView) findViewById(R.id.tv_result);
        tvResult.setMovementMethod(new ScrollingMovementMethod());

        // 标题栏左上角放图标（与客户端一致的草图 logo）
        try {
            ActionBar ab = getActionBar();
            if (ab != null) {
                ab.setLogo(R.mipmap.ic_launcher);
                ab.setDisplayUseLogoEnabled(true);
                ab.setDisplayShowHomeEnabled(true);
            }
        } catch (Throwable ignored) { }

        // 回填已保存的设置
        etServer.setText(P.server(this));
        etKey.setText(P.psk(this));
        etTether.setText(P.tetherCmd(this));

        btnConnect.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { onConnectClicked(); }
        });
        btnDisconnect.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (svc != null) svc.userRelease();
            }
        });
        btnCopy.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { copyResult(); }
        });
        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { if (svc != null) svc.clearLog(); }
        });
    }

    void onConnectClicked() {
        // 先持久化当前输入
        String server = etServer.getText().toString().trim();
        String key = etKey.getText().toString().trim();
        String tether = etTether.getText().toString().trim();
        P.saveServerPsk(this, server, key);
        P.saveTetherCmd(this, tether);

        if (!ensureLocationPermission()) {
            pendingConnect = true;   // 授权后再连
            return;
        }
        if (svc != null) svc.connect(server);
    }

    @Override protected void onStart() {
        super.onStart();
        // 用 startForegroundService 真正“启动”服务（而不仅仅是 bind），
        // 这样按返回键 Activity 销毁后，前台服务仍独立存活，PAN 不断开。
        Intent si = new Intent(this, PanService.class);
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(si);
            else startService(si);
        } catch (Throwable ignored) { }
        bindService(si, conn, BIND_AUTO_CREATE);
        bound = true;
    }

    @Override protected void onStop() {
        super.onStop();
        if (bound) {
            if (svc != null) svc.clearUi(ui);
            try { unbindService(conn); } catch (Throwable ignored) { }
            bound = false;
        }
    }

    // ---- 定位权限（Android 6+ 的 BLE 扫描需要 ACCESS_FINE_LOCATION）----
    boolean ensureLocationPermission() {
        if (Build.VERSION.SDK_INT < 23) return true;
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) return true;
        requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1001);
        return false;
    }

    @Override public void onRequestPermissionsResult(int req, String[] perms, int[] res) {
        if (req == 1001 && perms.length > 0 && res.length > 0
                && res[0] == PackageManager.PERMISSION_GRANTED && pendingConnect) {
            pendingConnect = false;
            String server = etServer.getText().toString().trim();
            if (svc != null) svc.connect(server);
        } else if (req == 1001 && pendingConnect) {
            pendingConnect = false;
            Toast.makeText(this, "Location permission is required to scan BLE", Toast.LENGTH_LONG).show();
        }
    }

    void copyResult() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("panclient", tvResult.getText().toString()));
        Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show();
    }
}
