package com.mypan.mypanclient;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

/**
 * 设置持久化：统一用默认 SharedPreferences（界面与后台服务共用）。
 * 关 App、重启设备都保留；卸载才丢。
 */
public class P {
    static SharedPreferences sp(Context c) {
        return PreferenceManager.getDefaultSharedPreferences(c);
    }

    static String server(Context c) { return sp(c).getString("server", "Cannon"); }
    static String psk(Context c) { return sp(c).getString("psk", ""); }
    static boolean autoConnect(Context c) { return sp(c).getBoolean("auto_connect", false); }

    /** RSSI 轮询间隔，秒；越界回落 3 */
    static int rssiSec(Context c) {
        int v = sp(c).getInt("rssi_sec", 3);
        return (v < 1 || v > 60) ? 3 : v;
    }

    /** 零片超时毫秒：发命令后等结果第一片的时间；0=不提示；越界回落 3500 */
    static int zeroChunkMs(Context c) {
        int v = sp(c).getInt("zero_chunk_ms", 3500);
        if (v == 0) return 0;
        return (v < 500 || v > 120000) ? 3500 : v;
    }

    /** RSSI 静默判死阈值，秒；0=不做静默判死（只靠协议栈 linkAlive）；越界回落 30 */
    static int rssiSilentSec(Context c) {
        int v = sp(c).getInt("rssi_silent_sec", 30);
        if (v == 0) return 0;
        return (v < 5 || v > 300) ? 30 : v;
    }

    /** 连上服务端后发送的「开启蓝牙共享」命令（在服务端以 root/系统权限执行）。
     *  默认调用 Termux 里的 panbg 脚本开启蓝牙共享(NAP)；如与服务端不匹配请自行修改。 */
    static String tetherCmd(Context c) {
        return sp(c).getString("tether_cmd",
                "/data/data/com.termux/files/home/apps/panbg on");
    }

    static void saveServerPsk(Context c, String server, String psk) {
        sp(c).edit().putString("server", server).putString("psk", psk).apply();
    }

    static void saveTetherCmd(Context c, String cmd) {
        sp(c).edit().putString("tether_cmd", cmd == null ? "" : cmd.trim()).apply();
    }

    static void savePsk(Context c, String psk) {
        sp(c).edit().putString("psk", psk == null ? "" : psk.trim()).apply();
    }
}
