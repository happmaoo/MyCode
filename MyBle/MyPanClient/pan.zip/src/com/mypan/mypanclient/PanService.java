package com.mypan.mypanclient;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

import java.lang.reflect.Method;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Date;
import java.util.Deque;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/**
 * 前台服务 = 唯一的 BLE 连接 + PAN 连接引擎。
 *
 * 与 mybleclient 的关系：复用同一套 BLE 传输协议（自定义 UUID、v2 T 帧可靠传输、
 * INDICATION 订阅、AUTH 流程），但只干一件事——
 *   1) 连上服务端（BLE GATT）；
 *   2) 就绪后自动发送「开启蓝牙共享」命令（在服务端以 root/系统权限执行）；
 *   3) 命令完成后，用 BluetoothPan（反射）以 PANU 身份连接服务端的 NAP，使本机走蓝牙共享上网。
 *
 * 所有连接状态都住在 Service 里：Activity 无论重建多少次，都只是 bind 上来"订阅状态"，
 * 不碰连接；熄屏/重建不会断链。
 */
public class PanService extends Service {

    static final int NOTIF_ID = 0x43;
    static final String CH_ID = "pan_conn";

    // ---- 与服务端约定的 UUID（必须和 BLEGattd 一致）----
    static final UUID SVC_CMD = UUID.fromString("8e7a1f01-2b3c-4d5e-6f70-8192a3b4c5d6");
    static final UUID CH_CMD  = UUID.fromString("8e7a1f03-2b3c-4d5e-6f70-8192a3b4c5d6");
    static final UUID CH_RES  = UUID.fromString("8e7a1f04-2b3c-4d5e-6f70-8192a3b4c5d6");
    static final UUID CH_AUTH = UUID.fromString("8e7a1f05-2b3c-4d5e-6f70-8192a3b4c5d6");
    static final UUID SVC_BAS = UUID.fromString("0000180f-0000-1000-8000-00805f9b34fb");
    static final UUID CH_BATT = UUID.fromString("00002a19-0000-1000-8000-00805f9b34fb");
    static final UUID CCCD    = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
    static final Charset UTF8 = Charset.forName("UTF-8");

    /** 界面回调：Activity 绑定后注册；重建后重新注册并收到全量快照 */
    public interface Ui {
        void onInfo(String s);        // 状态行 tvInfo
        void onBatt(String s);        // 电量/信号行 tvBatt
        void onPan(String s);         // PAN 状态行 tvPan（本 App 新增）
        void onLog(String s);         // 追加一条事件/结果块（已含时间戳格式）
        void onLogReset(String s);    // 整体重设日志区（重绑定时回放 logBuf / 清空）
        void onBtn(String text, boolean enabled); // Connect 按钮状态
        void onDisconnectBtn(boolean enabled);    // 断开按钮：未连接时禁用
        void onToast(String s);
    }

    public class LocalBinder extends Binder {
        public PanService getService() { return PanService.this; }
    }
    private final LocalBinder binder = new LocalBinder();
    @Override public IBinder onBind(Intent intent) { return binder; }

    volatile Ui uiCb;
    final Handler th = new Handler(Looper.getMainLooper());

    // ---- 全量状态快照：重建的界面靠它一次性恢复文字 ----
    String curInfo = "Not connected";
    String curBatt = "";
    String curPan  = "PAN: not connected";   // 本 App 新增
    String btnText = "Connect";
    boolean btnEnabled = true;
    boolean disconnectEnabled = false;
    final ArrayDeque<String> logBuf = new ArrayDeque<String>();
    static final int LOG_MAX = 400;

    // ------------------------------------------------------------- 引擎状态
    BluetoothAdapter adapter;
    BluetoothManager btManager;
    BluetoothGatt gatt;
    BluetoothDevice curDevice;
    BluetoothGattCharacteristic cBatt, cCmd, cRes, cAuth;

    final SimpleDateFormat ts = new SimpleDateFormat("HH:mm:ss", Locale.US);
    final Deque<W> wq = new ArrayDeque<W>();
    boolean writing = false;
    final java.io.ByteArrayOutputStream rx = new java.io.ByteArrayOutputStream();

    // ---- 可靠传输 v2 接收状态（T 帧：'T'+tid+seq+total+payload+CRC16）----
    int rvTid = -1;
    int rvDoneTid = -1;
    String serverVer = "";
    static final String APP_BUILD_DATE = "__BUILD_DATE__";
    static String appVersion() {
        String d = APP_BUILD_DATE.equals("__BUILD_DATE__") ? "dev" : APP_BUILD_DATE;
        return "2.0." + d;
    }
    int rvTotal = 0;
    int rvNext = 0;
    int rvNacks = 0;
    byte[] rvDigest = null;
    boolean rvDigestGot = false;
    boolean streaming = false;
    int streamChars = 0;

    int step = 0;
    int lastBattery = -1;
    int lastRssi = 0;
    long lastRssiOkAt = 0;
    int rssiBusy = 0;
    int hbTicks = 0;
    boolean linkUp = false;
    boolean connecting = false;
    boolean scanning = false;
    boolean waitingResult = false;
    boolean probing = false;
    int probeFails = 0;
    int probeRounds = 0;
    boolean probePending = false;
    boolean resSubscribed = false;
    String want = "";
    String mtuText = "";
    int curMtu = 23;

    /** 一条待写的 (特征, 内容)：AUTH 与 CMD 共用写队列但目标不同 */
    static final class W {
        final BluetoothGattCharacteristic ch;
        final byte[] v;
        W(BluetoothGattCharacteristic ch, byte[] v) { this.ch = ch; this.v = v; }
    }

    // ------------------------------------------------------------- 定时器
    final Runnable scanTimeout = new Runnable() {
        @Override public void run() {
            if (connecting || linkUp) return;
            stopScan();
            info("No match: " + want + " (confirm the server is running and the advertised name matches)");
            setBtn("Connect", true);
        }
    };

    final Runnable readyTimeout = new Runnable() {
        @Override public void run() {
            if (step >= 9 || gatt == null) return;
            info("Init timeout (stuck at step " + step + ")  -  connection released; please Connect again");
            logEvent("Init timeout step=" + step + ": an ATT request got no callback, or the peripheral process was restarted");
            hardClose();
        }
    };

    final Runnable chunkTimeout = new Runnable() {
        @Override public void run() {
            if (rvTid >= 0 && rvTotal > 1 && rvNext >= rvTotal && !rvDigestGot) {
                sendNack(rvTid, rvTotal, "digest frame missing");
                return;
            }
            if (rx.size() == 0) return;
            String half = new String(rx.toByteArray(), UTF8);
            abortRx();
            appendResult(half + "\n! Fragment incomplete (no follow-up within 4s; partial output shown)");
            info(linkUp ? readyText() + " (previous result incomplete)" : "Disconnected");
        }
    };

    final Runnable noChunkTimeout = new Runnable() {
        @Override public void run() {
            if (!waitingResult || rx.size() > 0) return;
            waitingResult = false;
            long ms = P.zeroChunkMs(PanService.this);
            appendResult("! " + (ms / 1000.0) + "s: no notification chunk received: server didn't send, or subscribe/link state invalid"
                    + " (server log will show why PUMP was skipped; duration adjustable elsewhere)");
            info(linkUp ? readyText() + " (no result returned)" : "Disconnected");
            if (linkUp) startProbe();
        }
    };

    final Runnable wakeProbe = new Runnable() {
        @Override public void run() {
            if (!probing || gatt == null || cCmd == null || !linkUp) { stopProbe(); return; }
            if (probePending) {
                onProbeFail();
                if (!probing) return;
            }
            if (probeRounds >= 3) {
                stopProbe();
                appendResult("! Probed 3 times with no real reply: server alive, command may be stuck; waiting for watchdog to reclaim");
                return;
            }
            probePending = true;
            probeRounds++;
            wq.add(new W(cCmd, "wakeupserver".getBytes(UTF8)));
            drain();
            th.postDelayed(wakeProbe, 5000);
        }
    };

    void startProbe() {
        if (probing || gatt == null || cCmd == null || !linkUp) return;
        probing = true; probeFails = 0; probeRounds = 0; probePending = false;
        th.removeCallbacks(wakeProbe);
        th.postDelayed(wakeProbe, 0);
    }

    void stopProbe() {
        probing = false; probeFails = 0; probeRounds = 0; probePending = false;
        th.removeCallbacks(wakeProbe);
    }

    void onProbeFail() {
        probeFails++;
        probePending = false;
        if (probeFails >= 3) {
            stopProbe();
            appendResult("! Server unresponsive: wakeupserver probe failed 3 times consecutively; link considered dead");
            boolean auto = P.autoConnect(PanService.this);
            hardClose();
            if (auto) th.postDelayed(autoConnectTask, 3000);
        }
    }

    final Runnable heartbeat = new Runnable() {
        @Override public void run() {
            if (gatt == null) return;
            int iv = Math.max(1, P.rssiSec(PanService.this));
            try {
                hbTicks++;
                if (!linkAlive()) {
                    boolean auto = P.autoConnect(PanService.this);
                    info(auto ? "Link disconnected (stack reported no GATT connection) - reconnecting"
                              : "Link disconnected (stack reported no GATT connection) - please reconnect manually");
                    logEvent("Heartbeat #" + hbTicks + ": linkAlive=false -> released and reset button");
                    hardClose();
                    if (auto) th.postDelayed(autoConnectTask, 3000);
                    return;
                }
                long silent = System.currentTimeMillis() - lastRssiOkAt;
                long lim = P.rssiSilentSec(PanService.this) * 1000L;
                if (lim > 0 && (lastRssiOkAt == 0 || silent > lim)) {
                    boolean auto = P.autoConnect(PanService.this);
                    info(auto ? "Link may be dead (RSSI silent " + (silent / 1000) + "s) - reconnecting"
                              : "Link may be dead (RSSI silent " + (silent / 1000) + "s) - please reconnect manually");
                    logEvent("Heartbeat #" + hbTicks + ": RSSI silent " + (silent / 1000)
                            + "s (threshold " + (lim / 1000) + "s), readRemoteRssi rejected "
                            + rssiBusy + " times -> releasing");
                    hardClose();
                    if (auto) th.postDelayed(autoConnectTask, 3000);
                    return;
                }
                boolean ok = false;
                try { ok = gatt.readRemoteRssi(); } catch (Throwable ignored) { }
                if (!ok) {
                    rssiBusy++;
                    if (rssiBusy == 1 || rssiBusy % 10 == 0) {
                        logEvent("readRemoteRssi rejected " + rssiBusy + " times (another op in flight on the link)");
                    }
                }
                refreshBattLine();
            } catch (Throwable t) {
                logEvent("Heartbeat error: " + t);
            } finally {
                th.postDelayed(this, iv * 1000L);
            }
        }
    };

    final Runnable autoConnectTask = new Runnable() {
        @Override public void run() { if (gatt == null && !linkUp) beginConnect(P.server(PanService.this)); }
    };

    final Runnable retryDrain = new Runnable() {
        @Override public void run() { drain(); }
    };

    // ---------------------------------------------------------------- 生命周期
    @Override
    public void onCreate() {
        super.onCreate();
        logEvent("MyPanClient " + appVersion() + " started (foreground service established)");
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null && nm.getNotificationChannel(CH_ID) == null) {
                NotificationChannel ch = new NotificationChannel(CH_ID, "PAN Connection",
                        NotificationManager.IMPORTANCE_LOW);
                ch.setShowBadge(false);
                nm.createNotificationChannel(ch);
            }
        }
        btManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        adapter = (btManager == null) ? null : btManager.getAdapter();
        if (adapter == null) info("This device has no Bluetooth, or Bluetooth service unavailable");
        // 监听 PAN 连接状态广播（BluetoothPan 连接/断开）
        IntentFilter f = new IntentFilter("android.bluetooth.pan.profile.action.CONNECTION_STATE_CHANGED");
        try { registerReceiver(panReceiver, f); } catch (Throwable t) { logEvent("Register PAN receiver failed: " + t); }
        // 立即挂前台通知：满足 startForegroundService 的 5 秒时限，且让服务一启动就有常驻通知
        goForeground("Not connected");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // START_STICKY：被系统回收后自动重启服务（保持“连上就不管”的常驻连接）
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        uiCb = null;
        removeAllTimers();
        stopScan();
        try { unregisterReceiver(panReceiver); } catch (Throwable ignored) { }
        disconnectPan();
        if (gatt != null) {
            try { gatt.disconnect(); gatt.close(); } catch (Throwable ignored) { }
            gatt = null;
        }
        stopForeground(true);
    }

    void removeAllTimers() {
        th.removeCallbacks(scanTimeout);
        th.removeCallbacks(readyTimeout);
        th.removeCallbacks(chunkTimeout);
        th.removeCallbacks(noChunkTimeout);
        th.removeCallbacks(heartbeat);
        th.removeCallbacks(autoConnectTask);
        th.removeCallbacks(retryDrain);
    }

    // ------------------------------------------------------------- 对 UI 的接口
    public void setUi(final Ui u) {
        uiCb = u;
        if (u == null) return;
        th.post(new Runnable() {
            @Override public void run() {
                if (uiCb != u) return;
                try {
                    u.onInfo(curInfo);
                    u.onBatt(curBatt);
                    u.onPan(curPan);
                    u.onBtn(btnText, btnEnabled);
                    u.onDisconnectBtn(disconnectEnabled);
                    StringBuilder sb = new StringBuilder();
                    for (String s : logBuf) sb.append(s);
                    u.onLogReset(sb.toString());
                } catch (Throwable ignored) { }
            }
        });
    }

    public void clearUi(Ui u) {
        if (uiCb == u) uiCb = null;
    }

    public void connect(final String name) {
        th.post(new Runnable() {
            @Override public void run() { beginConnect(name); }
        });
    }

    public void ensureAutoConnect() {
        th.post(new Runnable() {
            @Override public void run() {
                if (!P.autoConnect(PanService.this)) return;
                if (gatt != null || linkUp || connecting || scanning) return;
                logEvent("Auto-connect: " + P.server(PanService.this));
                beginConnect(P.server(PanService.this));
            }
        });
    }

    /** 发命令（本 App 内部用于发送「开启蓝牙共享」命令；就绪门槛在引擎里统一把关） */
    public void run(final String cmd) {
        th.post(new Runnable() {
            @Override public void run() {
                String c = cmd == null ? "" : cmd.trim();
                if (c.length() == 0) { toast("Command is empty"); return; }
                if (gatt == null || cCmd == null) { toast("Not connected / not ready yet"); return; }
                if (step < 9) { toast("Init not finished (step " + step + "); wait and retry"); return; }
                if (!resSubscribed) { toast("RES notify not subscribed; command output cannot be received"); return; }
                setConnPriority(BluetoothGatt.CONNECTION_PRIORITY_BALANCED);
                addLog("──── " + ts.format(new Date()) + " ────\n$ " + c + "\n\n");
                streaming = true; streamChars = 0;
                waitingResult = true;
                th.removeCallbacks(noChunkTimeout);
                int zc = P.zeroChunkMs(PanService.this);
                if (zc > 0) th.postDelayed(noChunkTimeout, zc);
                byte[] raw = c.getBytes(UTF8);
                int maxW = Math.max(20, curMtu - 3);
                if (raw.length <= maxW) {
                    wq.add(new W(cCmd, raw));
                } else {
                    int per = maxW - 1;
                    int frags = (raw.length + per - 1) / per;
                    logEvent("Command " + raw.length + " bytes exceed MTU (" + maxW + "), split into " + frags + " chunks to send");
                    for (int off = 0; off < raw.length; off += per) {
                        int len = Math.min(per, raw.length - off);
                        byte[] piece = new byte[len + 1];
                        piece[0] = (byte) ((off + len >= raw.length) ? '<' : '>');
                        System.arraycopy(raw, off, piece, 1, len);
                        wq.add(new W(cCmd, piece));
                    }
                }
                drain();
            }
        });
    }

    public void userRelease() {
        th.post(new Runnable() {
            @Override public void run() {
                removeAllTimers();
                stopScan();
                connecting = false;
                disconnectPan();
                if (gatt != null) {
                    try { gatt.disconnect(); gatt.close(); } catch (Throwable ignored) { }
                    gatt = null;
                }
                linkUp = false;
                curDevice = null;
                resetState();
                setBattIdle();
                info("Disconnected (manual)");
                setBtn("Connect", true);
                infoPan("PAN: not connected");
                updateNotif("Not connected");
                stopForeground(true);
                stopSelf();
            }
        });
    }

    public void clearLog() {
        th.post(new Runnable() {
            @Override public void run() {
                logBuf.clear();
                Ui u = uiCb;
                if (u != null) { try { u.onLogReset(""); } catch (Throwable ignored) { } }
            }
        });
    }

    // ---------------------------------------------------------------- 扫描连接
    void beginConnect(String name) {
        if (name == null || name.trim().length() == 0) { toast("Please enter the advertised name"); return; }
        want = name.trim();
        if (adapter == null || !adapter.isEnabled()) { info("Bluetooth is off; please turn it on first"); setBtn("Connect", true); return; }
        startScan();
    }

    void startScan() {
        setBtn("Scanning…", false);
        connecting = false;
        goForeground("Scan/Connect " + want + " …");
        final BluetoothLeScanner sc = adapter.getBluetoothLeScanner();
        if (sc == null) { info("Cannot get BLE scanner"); setBtn("Connect", true); return; }
        List<ScanFilter> fs = new ArrayList<ScanFilter>();
        fs.add(new ScanFilter.Builder().setDeviceName(want).build());
        ScanSettings st = new ScanSettings.Builder()
                .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build();
        info("Scanning: " + want + " …");
        scanning = true;
        try {
            sc.startScan(fs, st, scanCb);
            th.postDelayed(scanTimeout, 12000);
        } catch (SecurityException e) {
            scanning = false;
            info("Missing permission, cannot scan: " + e.getMessage());
            setBtn("Connect", true);
        }
    }

    void stopScan() {
        scanning = false;
        try {
            if (adapter == null) return;
            BluetoothLeScanner sc = adapter.getBluetoothLeScanner();
            if (sc != null) sc.stopScan(scanCb);
        } catch (Throwable ignored) { }
    }

    final ScanCallback scanCb = new ScanCallback() {
        @Override public void onScanResult(int callbackType, final ScanResult result) {
            th.post(new Runnable() {
                @Override public void run() {
                    BluetoothDevice d = result.getDevice();
                    String name = safeName(d, result);
                    if (name == null || !name.equalsIgnoreCase(want)) return;
                    connecting = true;
                    scanning = false;
                    th.removeCallbacks(scanTimeout);
                    stopScan();
                    byte[] adv = null;
                    try {
                        if (result.getScanRecord() != null) adv = result.getScanRecord().getBytes();
                    } catch (Throwable ignored) { }
                    String advHex = "(empty)";
                    if (adv != null && adv.length > 0) {
                        int end = adv.length;
                        while (end > 0 && adv[end - 1] == 0) end--;
                        if (end == 0) end = adv.length;
                        advHex = "0x" + hex(java.util.Arrays.copyOf(adv, end)) + " (" + end + " Byte)";
                    }
                    logBuf.clear();
                    Ui u = uiCb;
                    if (u != null) { try { u.onLogReset(""); } catch (Throwable ignored) { } }
                    logEvent("Target found " + d.getAddress() + " RSSI " + result.getRssi()
                            + "dBm, advertising data " + advHex);
                    connectDevice(d, result.getRssi());
                }
            });
        }

        @Override public void onScanFailed(final int errorCode) {
            th.post(new Runnable() {
                @Override public void run() {
                    scanning = false;
                    info("Scan failed code=" + errorCode + " (usually Bluetooth/location not ready)");
                    th.removeCallbacks(scanTimeout);
                    setBtn("Connect", true);
                }
            });
        }
    };

    String safeName(BluetoothDevice d, ScanResult r) {
        try {
            String n = d.getName();
            if (n != null) return n;
        } catch (Throwable ignored) { }
        try {
            if (r.getScanRecord() != null) return r.getScanRecord().getDeviceName();
        } catch (Throwable ignored) { }
        return null;
    }

    static String hex(byte[] b) {
        if (b == null || b.length == 0) return "";
        StringBuilder sb = new StringBuilder(b.length * 2);
        for (byte x : b) sb.append(String.format("%02X", x));
        return sb.toString();
    }

    String readyText() {
        String s = "Connected " + ((curDevice != null) ? curDevice.getAddress() : want);
        s += " · App " + appVersion();
        if (serverVer != null && !serverVer.isEmpty()) s += " · server " + serverVer;
        return s;
    }

    void connectDevice(BluetoothDevice d, final int rssi) {
        if (gatt != null) { try { gatt.close(); } catch (Throwable ignored) { } gatt = null; }
        curDevice = d;
        resetState();
        lastRssi = rssi;
        refreshBattLine();
        setBtn("Connecting…", false);
        info("Connecting " + d.getAddress() + " (RSSI " + rssi + ")…");
        goForeground("Connecting " + want + " …");
        th.postDelayed(readyTimeout, 15000);
        if (Build.VERSION.SDK_INT >= 23) {
            gatt = d.connectGatt(this, false, gattCb, BluetoothDevice.TRANSPORT_LE);
        } else {
            gatt = d.connectGatt(this, false, gattCb);
        }
    }

    void hardClose() {
        linkUp = false;
        connecting = false;
        th.removeCallbacks(readyTimeout);
        th.removeCallbacks(chunkTimeout);
        th.removeCallbacks(noChunkTimeout);
        th.removeCallbacks(heartbeat);
        if (gatt != null) {
            try { gatt.disconnect(); gatt.close(); } catch (Throwable ignored) { }
            gatt = null;
        }
        curDevice = null;
        resetState();
        setBattIdle();
        info("Not connected");
        updateNotif("Not connected");
        setBtn("Connect", true);
    }

    void resetState() {
        stopProbe();
        cBatt = null; cCmd = null; cRes = null; cAuth = null;
        wq.clear();
        writing = false;
        abortRx();
        step = 0;
        mtuText = "";
        curMtu = 23;
        lastBattery = -1;
        waitingResult = false;
        resSubscribed = false;
        serverVer = "";
        tetherPending = false;
    }

    boolean linkAlive() {
        if (gatt == null) return false;
        try {
            if (btManager != null && curDevice != null) {
                return btManager.getConnectionState(curDevice, BluetoothProfile.GATT)
                        == BluetoothProfile.STATE_CONNECTED;
            }
        } catch (Throwable ignored) { }
        return linkUp;
    }

    // ------------------------------------------------------------- GATT 客户端
    final BluetoothGattCallback gattCb = new BluetoothGattCallback() {
        @Override public void onConnectionStateChange(final BluetoothGatt g, final int status, final int newState) {
            th.post(new Runnable() { @Override public void run() { onConnState(g, status, newState); } });
        }
        @Override public void onServicesDiscovered(final BluetoothGatt g, final int status) {
            th.post(new Runnable() { @Override public void run() { onSvcDiscovered(g, status); } });
        }
        @Override public void onMtuChanged(final BluetoothGatt g, final int mtu, final int status) {
            th.post(new Runnable() { @Override public void run() { onMtu(g, mtu, status); } });
        }
        @Override public void onCharacteristicRead(final BluetoothGatt g, final BluetoothGattCharacteristic ch, final int status) {
            th.post(new Runnable() { @Override public void run() { onCharRead(g, ch, status); } });
        }
        @Override public void onCharacteristicWrite(final BluetoothGatt g, final BluetoothGattCharacteristic ch, final int status) {
            th.post(new Runnable() { @Override public void run() { onCharWrite(g, ch, status); } });
        }
        @Override public void onDescriptorWrite(final BluetoothGatt g, final BluetoothGattDescriptor d, final int status) {
            th.post(new Runnable() { @Override public void run() { onDescWrite(g, d, status); } });
        }
        @Override public void onReadRemoteRssi(final BluetoothGatt g, final int rssi, final int status) {
            th.post(new Runnable() { @Override public void run() { onRssi(g, rssi, status); } });
        }
        @Override public void onCharacteristicChanged(final BluetoothGatt g, final BluetoothGattCharacteristic ch) {
            th.post(new Runnable() { @Override public void run() { onNotify(g, ch); } });
        }
    };

    void onConnState(BluetoothGatt g, int status, int newState) {
        if (g != gatt) { logEvent("Ignore stale gatt object connect event state=" + newState); return; }
        if (newState == BluetoothProfile.STATE_CONNECTED) {
            linkUp = true;
            logEvent("Connected " + g.getDevice().getAddress());
            goForeground("Connected " + want + ", initializing…");
            setBtn("Connected", false);
            info("Connected, discovering services…");
            g.discoverServices();
        } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
            if (status != BluetoothGatt.GATT_SUCCESS && status != 19) {
                info("Connection interrupted status=" + status + " (peripheral may have restarted)");
            } else {
                info("Disconnected");
            }
            th.removeCallbacks(readyTimeout);
            th.removeCallbacks(heartbeat);
            updateNotif("Disconnected");
            setBtn("Connect", true);
            try { g.close(); } catch (Throwable ignored) { }
            gatt = null;
            curDevice = null;
            linkUp = false;
            connecting = false;
            resetState();
            setBattIdle();
            disconnectPan();
            stopForeground(true);
            if (P.autoConnect(this)) th.postDelayed(autoConnectTask, 4000);
        }
    }

    void onSvcDiscovered(BluetoothGatt g, int status) {
        if (g != gatt) return;
        BluetoothGattService cmd = null, bas = null;
        try {
            cmd = g.getService(SVC_CMD);
            bas = g.getService(SVC_BAS);
        } catch (Throwable t) { }
        if (cmd != null) {
            cCmd  = cmd.getCharacteristic(CH_CMD);
            cRes  = cmd.getCharacteristic(CH_RES);
            cAuth = cmd.getCharacteristic(CH_AUTH);
        }
        if (bas != null) cBatt = bas.getCharacteristic(CH_BATT);
        logEvent("Service discovery: BAS=" + (bas != null) + " 2A19=" + (cBatt != null)
                + " cmd=" + (cmd != null) + " CMD=" + (cCmd != null)
                + " RES=" + (cRes != null) + " AUTH=" + (cAuth != null));
        if (cCmd == null && cBatt == null) {
            th.removeCallbacks(readyTimeout);
            info("Expected characteristic not found - confirm this is the server and the service is registered");
            return;
        }
        g.requestMtu(517);
    }

    void onMtu(BluetoothGatt g, int mtu, int status) {
        if (g != gatt) return;
        curMtu = mtu;
        mtuText = "MTU " + mtu;
        logEvent("MTU negotiated " + mtu + " (usable per chunk " + Math.max(1, mtu - 4) + " bytes)");
        step = 1;
        runStep();
    }

    void onCharRead(BluetoothGatt g, BluetoothGattCharacteristic ch, int status) {
        if (g != gatt) return;
        if (CH_BATT.equals(ch.getUuid()) && status == BluetoothGatt.GATT_SUCCESS) {
            showBattery(ch.getValue());
        }
        step = 2;
        runStep();
    }

    void onCharWrite(BluetoothGatt g, BluetoothGattCharacteristic ch, int status) {
        if (g != gatt) return;
        writing = false;
        if (status != BluetoothGatt.GATT_SUCCESS) {
            info("Write failed status=" + status);
            logEvent("Write " + shortOf(ch.getUuid()) + " failed status=" + status);
        }
        drain();
    }

    void onDescWrite(BluetoothGatt g, BluetoothGattDescriptor d, int status) {
        if (g != gatt) return;
        if (status != BluetoothGatt.GATT_SUCCESS) {
            info("Subscribe failed status=" + status);
            logEvent("Subscribe CCCD failed status=" + status + " (server may not have declared NOTIFY)");
        } else {
            if (CH_RES.equals(uuidOf(d))) resSubscribed = true;
            logEvent("Subscribed: " + shortOf(uuidOf(d))
                    + (CH_RES.equals(uuidOf(d)) ? " (result channel ready)" : ""));
        }
        step = step + 1;
        runStep();
    }

    void onRssi(BluetoothGatt g, int rssi, int status) {
        if (g != gatt) return;
        if (status == BluetoothGatt.GATT_SUCCESS) {
            lastRssi = rssi;
            lastRssiOkAt = System.currentTimeMillis();
            refreshBattLine();
        } else {
            logEvent("readRemoteRssi Back status=" + status);
        }
    }

    void onNotify(BluetoothGatt g, BluetoothGattCharacteristic ch) {
        if (g != gatt) return;
        byte[] v = ch.getValue();
        if (v == null || v.length == 0) return;
        if (CH_BATT.equals(ch.getUuid())) {
            showBattery(v);
        } else if (CH_RES.equals(ch.getUuid())) {
            handleChunk(v);
        }
    }

    static UUID uuidOf(BluetoothGattDescriptor d) {
        try {
            BluetoothGattCharacteristic c = d.getCharacteristic();
            return c == null ? CCCD : c.getUuid();
        } catch (Throwable t) { return CCCD; }
    }

    void runStep() {
        BluetoothGatt g = gatt;
        if (g == null) return;
        if (step == 1) { if (cBatt != null) { g.readCharacteristic(cBatt); return; } step = 2; }
        if (step == 2) { if (cBatt != null && enableNotify(cBatt)) return; step = 3; }
        if (step == 3) { if (cRes != null && enableNotify(cRes)) return; step = 4; }
        if (step == 4) {
            if (cAuth != null) {
                String key = P.psk(this).trim();
                logEvent("Write AUTH (key " + key.length() + " chars)…");
                wq.add(new W(cAuth, key.getBytes(UTF8)));
                drain();
            }
            step = 9;
        }
        if (step == 9) {
            th.removeCallbacks(readyTimeout);
            lastRssiOkAt = System.currentTimeMillis();
            th.removeCallbacks(heartbeat);
            th.postDelayed(heartbeat, 1000);
            setConnPriority(BluetoothGatt.CONNECTION_PRIORITY_LOW_POWER);
            info(readyText());
            updateNotif(readyText());
            logEvent("Ready(" + readyText() + "): " + (cBatt != null ? "Battery Level readable/subscribable; " : "no battery service; ")
                    + (cCmd != null ? "command channel available" : "no command channel"));
            // 本 App 的核心：就绪后自动发起「开启蓝牙共享 → 连接 PAN」流程
            startPanFlow();
        }
    }

    void setConnPriority(int mode) {
        try {
            if (gatt != null) gatt.requestConnectionPriority(mode);
        } catch (Throwable ignored) { }
    }

    boolean enableNotify(BluetoothGattCharacteristic ch) {
        if (ch == null || gatt == null) return false;
        if (!gatt.setCharacteristicNotification(ch, true)) {
            logEvent("setCharacteristicNotification failed: " + shortOf(ch.getUuid()));
            return false;
        }
        BluetoothGattDescriptor cd = ch.getDescriptor(CCCD);
        if (cd == null) {
            logEvent(shortOf(ch.getUuid()) + " has no CCCD, read-only, cannot notify");
            return false;
        }
        if (CH_RES.equals(ch.getUuid())) {
            cd.setValue(BluetoothGattDescriptor.ENABLE_INDICATION_VALUE);
            logEvent("Subscribe " + shortOf(ch.getUuid()) + ": INDICATION (reliable flow control)");
        } else {
            cd.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
        }
        return gatt.writeDescriptor(cd);
    }

    // ------------------------------------------------------ 电量 / 信号 / 结果
    void showBattery(byte[] v) {
        if (v == null || v.length == 0) { logEvent("Battery value empty"); return; }
        lastBattery = v[0] & 0xFF;
        refreshBattLine();
    }

    void refreshBattLine() {
        final String line;
        if (!linkUp) {
            line = "";
        } else {
            line = "Battery: " + (lastBattery < 0 ? " - " : lastBattery + "%")
                    + "   Signal: " + (lastRssi == 0 ? " - " : lastRssi + " dBm")
                    + "   " + ts.format(new Date());
        }
        curBatt = line;
        Ui u = uiCb;
        if (u != null) { try { u.onBatt(line); } catch (Throwable ignored) { } }
        updateNotif((lastBattery < 0 ? "" : lastBattery + "%  ")
                + (lastRssi == 0 ? "" : lastRssi + " dBm"));
    }

    void setBattIdle() {
        lastBattery = -1;
        lastRssi = 0;
        refreshBattLine();
    }

    /** 服务端 v2 可靠传输协议：T 帧(数据)/D 帧(校验)/! 帧(错误)，逐帧 CRC16 + 整包 SHA-256。 */
    void handleChunk(byte[] v) {
        waitingResult = false;
        th.removeCallbacks(noChunkTimeout);
        if (v == null || v.length == 0) return;
        char mark = (char) (v[0] & 0xFF);
        if (mark == 'T') {
            if (v.length < 9) return;
            int crc = ((v[v.length - 2] & 0xFF) << 8) | (v[v.length - 1] & 0xFF);
            int tid = ((v[1] & 0xFF) << 8) | (v[2] & 0xFF);
            if (crc16(v, 0, v.length - 2) != crc) {
                if (tid == rvTid) {
                    int seq = ((v[3] & 0xFF) << 8) | (v[4] & 0xFF);
                    sendNack(tid, seq, "CRC16 check failed");
                }
                return;
            }
            int seq = ((v[3] & 0xFF) << 8) | (v[4] & 0xFF);
            int total = ((v[5] & 0xFF) << 8) | (v[6] & 0xFF);
            if (tid != rvTid) {
                rx.reset();
                rvTid = tid; rvTotal = total; rvNext = 0; rvNacks = 0;
                rvDigest = null; rvDigestGot = false;
            }
            if (seq < rvNext) return;
            if (seq > rvNext) {
                sendNack(tid, rvNext, "missing seq " + rvNext + " (received " + seq + ")");
                return;
            }
            try { rx.write(v, 7, v.length - 9); } catch (Throwable ignored) { }
            rvNext++;
            if (rvTotal > 1) th.postDelayed(chunkTimeout, 4000);
            info("Receiving... chunk " + rvNext + "/" + rvTotal + ", got " + rx.size() + " bytes");
            if (rvTotal == 1) completeRx();
            return;
        }
        if (mark == 'D') {
            if (v.length < 37) return;
            int crc = ((v[v.length - 2] & 0xFF) << 8) | (v[v.length - 1] & 0xFF);
            if (crc16(v, 0, v.length - 2) != crc) return;
            int tid = ((v[1] & 0xFF) << 8) | (v[2] & 0xFF);
            if (tid == rvTid && rvNext >= rvTotal && !rvDigestGot && rvTotal > 1) {
                rvDigest = new byte[32];
                System.arraycopy(v, 3, rvDigest, 0, 32);
                rvDigestGot = true;
                verifyDigest();
            }
            return;
        }
        if (mark == '!') {
            if (tetherPending) onTetherDone();  // 命令报错也照样去连 PAN（可能共享已开）
            abortRx();
            appendResult("✗ " + new String(v, 1, v.length - 1, UTF8));
        }
    }

    static int crc16(byte[] b, int off, int len) {
        int crc = 0xFFFF;
        for (int i = off; i < off + len; i++) {
            crc ^= (b[i] & 0xFF) << 8;
            for (int j = 0; j < 8; j++) {
                crc = ((crc & 0x8000) != 0) ? ((crc << 1) ^ 0x1021) & 0xFFFF : (crc << 1) & 0xFFFF;
            }
        }
        return crc;
    }

    void verifyDigest() {
        try {
            byte[] actual = java.security.MessageDigest.getInstance("SHA-256")
                    .digest(rx.toByteArray());
            if (java.util.Arrays.equals(actual, rvDigest)) { completeRx(); return; }
        } catch (Throwable ignored) { }
        logEvent("SHA-256 mismatch: discarding " + rx.size() + " bytes, requesting full retransmit");
        rx.reset();
        rvNext = 0;
        rvDigestGot = false;
        rvDigest = null;
        sendNack(rvTid, 0, "SHA-256 mismatch, full retransmit");
    }

    void completeRx() {
        th.removeCallbacks(chunkTimeout);
        byte[] data = rx.toByteArray();
        abortRx();
        String whole = new String(data, UTF8);
        String wholeTrim = whole.trim();
        if ("wakeup-ok".equals(wholeTrim)) {
            probePending = false;
            return;
        }
        stopProbe();
        if (wholeTrim.startsWith("blegatt-ver:")) {
            serverVer = wholeTrim.substring("blegatt-ver:".length()).trim();
            logEvent("Received server version: " + serverVer);
            if (linkUp) info(readyText());
            return;
        }
        if (wholeTrim.startsWith("!")) {
            if (tetherPending) onTetherDone();
            finishStream();
            appendResult("✗ " + whole.trim().substring(1));
            logEvent("Server: " + whole.trim());
            setConnPriority(BluetoothGatt.CONNECTION_PRIORITY_LOW_POWER);
            if (linkUp) info(readyText());
            return;
        }
        if ("auth:ok".equals(wholeTrim)) { rememberKey(); setConnPriority(BluetoothGatt.CONNECTION_PRIORITY_LOW_POWER); if (linkUp) info(readyText()); return; }
        if (wholeTrim.startsWith("#rc=")) {
            if (tetherPending) onTetherDone();   // 开启共享命令结束 → 去连 PAN
            finishStream();
            int code = -1;
            try { code = Integer.parseInt(wholeTrim.substring(4).trim()); } catch (Throwable ignored) { }
            addLog("· " + ts.format(new Date()) + " Command finished (exit code " + code + "), received " + streamChars + " chars (CRC/SHA verified)\n");
            setConnPriority(BluetoothGatt.CONNECTION_PRIORITY_LOW_POWER);
            if (linkUp) info(readyText());
            return;
        }
        if (!streaming) { addLog("──── " + ts.format(new Date()) + " ────\n"); streaming = true; streamChars = 0; }
        addLog(whole);
        streamChars += whole.length();
        if (linkUp) info(readyText());
    }

    void finishStream() {
        if (streaming) { addLog("\n"); streaming = false; }
    }

    void sendNack(int tid, int fromSeq, String why) {
        th.removeCallbacks(chunkTimeout);
        if (rvNacks >= 5) {
            abortRx();
            appendResult("! Retransmit requested 5 times without completion (tid=" + tid + "), giving up this round");
            setConnPriority(BluetoothGatt.CONNECTION_PRIORITY_LOW_POWER);
            if (linkUp) info(readyText() + " (last transfer failed)");
            return;
        }
        rvNacks++;
        String msg = "#retrans " + tid + " " + fromSeq;
        logEvent("Retransmit requested: " + msg + " (" + why + ")");
        if (gatt != null && cCmd != null) {
            wq.add(new W(cCmd, msg.getBytes(UTF8)));
            drain();
        }
        th.postDelayed(chunkTimeout, 4000);
    }

    void abortRx() {
        th.removeCallbacks(chunkTimeout);
        rx.reset();
        rvTid = -1; rvTotal = 0; rvNext = 0; rvNacks = 0;
        rvDigest = null; rvDigestGot = false;
        rvDoneTid = -1;
    }

    void drain() {
        if (writing || wq.isEmpty() || gatt == null) return;
        W w = wq.poll();
        writing = true;
        w.ch.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
        w.ch.setValue(w.v);
        if (!gatt.writeCharacteristic(w.ch)) {
            writing = false;
            wq.addFirst(w);
            info("Write request submit failed (previous one not done)");
            logEvent("Write " + shortOf(w.ch.getUuid()) + " submit failed, retry in 400ms");
            th.postDelayed(retryDrain, 400);
        }
    }

    void rememberKey() {
        String k = P.psk(this).trim();
        if (k.length() == 0) return;
        P.savePsk(this, k);
        logEvent("Key remembered (auto-filled on next launch; no key is built into the APK)");
    }

    // ============================================================ PAN 连接（核心新增）
    // 服务端启用蓝牙共享后，本机以 PANU 身份连上去即可走蓝牙共享上网。
    // 注意：编译桩(android-11)不含 BluetoothPan 类，因此不在编译期引用它——
    // 代理对象以基类 BluetoothProfile 持有，connect/disconnect 用反射调用，
    // PAN profile 常量用字面量 5（即 BluetoothProfile.PAN）。
    static final int PAN_PROFILE = 5;    // BluetoothProfile.PAN
    BluetoothProfile pan = null;
    int panState = BluetoothProfile.STATE_DISCONNECTED;
    boolean panConnecting = false;
    boolean tetherPending = false;       // 开启共享命令发送中，完成后触发 PAN 连接
    static final int PAN_MAX_RETRY = 5;  // PAN 经典链路偶尔握手失败，自动重试
    int panRetry = 0;

    final BluetoothProfile.ServiceListener panListener = new BluetoothProfile.ServiceListener() {
        @Override public void onServiceConnected(int profile, BluetoothProfile proxy) {
            if (profile != PAN_PROFILE) return;
            pan = proxy;
            logEvent("PAN profile proxy obtained");
            if (panConnecting && curDevice != null) doPanConnect(curDevice);
        }
        @Override public void onServiceDisconnected(int profile) {
            if (profile == PAN_PROFILE) pan = null;
        }
    };

    /** 就绪后的主流程：发送「开启蓝牙共享」命令，命令完成再去连 PAN */
    void startPanFlow() {
        String cmd = P.tetherCmd(this).trim();
        if (cmd.length() == 0) {
            logEvent("No tether command configured; connecting PAN directly (assume server already sharing)");
            connectPan(curDevice);
            return;
        }
        logEvent("Sending tether command: " + cmd);
        tetherPending = true;
        run(cmd);
    }

    /** 开启共享命令结束（成功或失败都算）→ 稍等让 NAP 的 SDP 记录注册好，再连 PAN */
    void onTetherDone() {
        tetherPending = false;
        logEvent("Tether command done; waiting briefly for NAP SDP record, then connecting PAN…");
        th.postDelayed(new Runnable() { public void run() { connectPan(curDevice); } }, 1200);
    }

    /** 以 PANU 身份连接服务端的 NAP（蓝牙共享网络） */
    void connectPan(BluetoothDevice d) {
        if (d == null) { logEvent("PAN connect skipped: no device"); return; }
        if (panState == BluetoothProfile.STATE_CONNECTED) {
            logEvent("PAN already CONNECTED, skip");
            return;
        }
        panConnecting = true;
        panRetry = 0;
        panState = BluetoothProfile.STATE_DISCONNECTED;
        infoPan("PAN: connecting to " + d.getAddress() + " (as PANU) …");
        logEvent("Requesting BluetoothPan profile proxy…");
        if (adapter != null) adapter.getProfileProxy(this, panListener, PAN_PROFILE);
    }

    /** 真正发起连接（在拿到 PAN profile 代理后调用） */
    void doPanConnect(BluetoothDevice d) {
        if (pan == null || d == null) return;
        // 关键：从 BLE 扫描拿到的 device 对象常被缓存为 "LE 类型"，而 PAN 是纯经典 profile。
        // 用 getRemoteDevice 重新取一个"未标记类型"的设备对象，避免栈层面对 LE 对象走经典连接的怪异处理。
        // 地址不变（双模设备 LE 与经典同 MAC），只换一个"干净"的对象。
        BluetoothDevice dev = d;
        try { if (adapter != null) dev = adapter.getRemoteDevice(d.getAddress()); } catch (Throwable ignored) { }
        int bond = BluetoothDevice.BOND_NONE;
        try { bond = dev.getBondState(); } catch (Throwable ignored) { }
        logEvent("PAN target " + dev.getAddress()
                + "  type=" + devTypeText(dev.getType())
                + "  bond=" + bondStateText(bond));
        if (bond != BluetoothDevice.BOND_BONDED) {
            logEvent("WARNING: device NOT bonded (paired). BluetoothPan.connect needs a classic pairing — "
                    + "pair the two devices in system Bluetooth settings first, otherwise PAN connect will fail");
        }
        try {
            Method m = Class.forName("android.bluetooth.BluetoothPan").getMethod("connect", BluetoothDevice.class);
            Object r = m.invoke(pan, dev);
            // 某些 ROM 的 connect() 会同步返回 false（上一次还挂起 / 经典身份未就绪）→ 视为本次失败，走重试
            boolean ok = !(r instanceof Boolean) || ((Boolean) r);
            logEvent("BluetoothPan.connect(" + dev.getAddress() + ") invoked -> " + r);
            if (!ok) onPanFailed();
        } catch (Throwable t) {
            logEvent("BluetoothPan.connect failed: " + t);
            onPanFailed();
        }
    }

    /** 连接失败（API 返回 false 或广播回到 DISCONNECTED）→ 自动重试，耗尽后放弃 */
    void onPanFailed() {
        if (panRetry < PAN_MAX_RETRY) {
            panRetry++;
            logEvent("PAN connect attempt failed; retry " + panRetry + "/" + PAN_MAX_RETRY + " in 2s");
            infoPan("PAN: retry " + panRetry + "/" + PAN_MAX_RETRY + " …");
            th.postDelayed(new Runnable() { public void run() {
                if (panConnecting && curDevice != null) doPanConnect(curDevice);
            } }, 2000);
        } else {
            panConnecting = false;
            infoPan("PAN: failed to connect after " + PAN_MAX_RETRY + " retries (check pairing / server PAN)");
        }
    }

    static String devTypeText(int t) {
        switch (t) {
            case 1: return "CLASSIC(1)";
            case 2: return "LE(2)";
            case 3: return "DUAL(3)";
            default: return "UNKNOWN(0)";
        }
    }

    static String bondStateText(int b) {
        switch (b) {
            case BluetoothDevice.BOND_BONDED: return "BONDED";
            case BluetoothDevice.BOND_BONDING: return "BONDING";
            default: return "NONE";
        }
    }

    /** 断开 PAN（反射调用 disconnect + 关闭 profile 代理） */
    void disconnectPan() {
        panConnecting = false;
        try {
            if (adapter != null && pan != null && curDevice != null) {
                Method m = Class.forName("android.bluetooth.BluetoothPan").getMethod("disconnect", BluetoothDevice.class);
                m.invoke(pan, curDevice);
            }
        } catch (Throwable t) { logEvent("BluetoothPan.disconnect failed: " + t); }
        try { if (adapter != null && pan != null) adapter.closeProfileProxy(PAN_PROFILE, pan); } catch (Throwable ignored) { }
        pan = null;
        panState = BluetoothProfile.STATE_DISCONNECTED;
    }

    /** 监听 PAN 连接状态广播：android.bluetooth.pan.profile.action.CONNECTION_STATE_CHANGED */
    final BroadcastReceiver panReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context ctx, Intent intent) {
            String action = intent.getAction();
            if (!"android.bluetooth.pan.profile.action.CONNECTION_STATE_CHANGED".equals(action)) return;
            int st = intent.getIntExtra(BluetoothProfile.EXTRA_STATE, BluetoothProfile.STATE_DISCONNECTED);
            BluetoothDevice d = (BluetoothDevice) intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
            panState = st;
            logEvent("PAN connection state -> " + panStateText(st) + (d != null ? " " + d.getAddress() : ""));
            if (st == BluetoothProfile.STATE_CONNECTED) {
                panConnecting = false;
                panRetry = 0;
                infoPan("PAN: CONNECTED to " + (d != null ? d.getAddress() : ""));
            } else if (st == BluetoothProfile.STATE_CONNECTING) {
                infoPan("PAN: connecting…");
            } else if (st == BluetoothProfile.STATE_DISCONNECTING) {
                infoPan("PAN: disconnecting…");
            } else {
                // DISCONNECTED：若我们正处于连接尝试中，则视为失败 → 自动重试
                if (panConnecting) onPanFailed();
                else infoPan("PAN: disconnected");
            }
        }
    };

    static String panStateText(int st) {
        switch (st) {
            case BluetoothProfile.STATE_CONNECTED: return "CONNECTED";
            case BluetoothProfile.STATE_CONNECTING: return "CONNECTING";
            case BluetoothProfile.STATE_DISCONNECTING: return "DISCONNECTING";
            default: return "DISCONNECTED";
        }
    }

    // ------------------------------------------------------------------ 显示
    void info(String s) {
        curInfo = s;
        Ui u = uiCb;
        if (u != null) { try { u.onInfo(s); } catch (Throwable ignored) { } }
    }

    void infoPan(String s) {
        curPan = s;
        Ui u = uiCb;
        if (u != null) { try { u.onPan(s); } catch (Throwable ignored) { } }
    }

    void appendResult(String text) {
        addLog("──── " + ts.format(new Date()) + " ────\n" + text + "\n\n");
    }

    void logEvent(String s) {
        addLog("· " + ts.format(new Date()) + "  " + s + "\n");
    }

    void addLog(String s) {
        logBuf.addLast(s);
        while (logBuf.size() > LOG_MAX) logBuf.pollFirst();
        Ui u = uiCb;
        if (u != null) { try { u.onLog(s); } catch (Throwable ignored) { } }
    }

    void setBtn(String text, boolean enabled) {
        btnText = text;
        btnEnabled = enabled;
        disconnectEnabled = !enabled && "Connected".equals(text);
        Ui u = uiCb;
        if (u != null) {
            try { u.onBtn(text, enabled); } catch (Throwable ignored) { }
            try { u.onDisconnectBtn(disconnectEnabled); } catch (Throwable ignored) { }
        }
    }

    void toast(String s) {
        Ui u = uiCb;
        if (u != null) { try { u.onToast(s); } catch (Throwable ignored) { } }
        else logEvent(s);
    }

    // ------------------------------------------------------------ 前台通知
    void goForeground(String text) {
        try { startForeground(NOTIF_ID, build(text)); } catch (Throwable t) { logEvent("Foreground notification failed: " + t); }
    }

    void updateNotif(String text) {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(NOTIF_ID, build(text));
        } catch (Throwable ignored) { }
    }

    Notification build(String text) {
        Intent open = new Intent(this, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open,
                Build.VERSION.SDK_INT >= 23
                        ? (PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE)
                        : PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = (Build.VERSION.SDK_INT >= 26)
                ? new Notification.Builder(this, CH_ID)
                : new Notification.Builder(this);
        b.setContentTitle("MyPanClient")
         .setContentText(text == null || text.length() == 0 ? "Not connected" : text)
         .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
         .setContentIntent(pi)
         .setOngoing(true);
        if (Build.VERSION.SDK_INT >= 24) b.setShowWhen(false);
        return b.build();
    }

    static String shortOf(UUID u) {
        String s = u.toString();
        return s.length() >= 8 ? s.substring(4, 8) : s;
    }
}
