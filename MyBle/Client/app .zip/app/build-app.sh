#!/bin/bash
# 不用 Gradle / AndroidX，直接 aapt2 + javac + d8 + zipalign + apksigner 出 APK
# 关键：javac 失败必须立刻终止；每次构建用全新 obj/dex 目录，绝不复用旧产物
set -e
JDK=/usr/lib/jvm/java-17-openjdk-amd64/bin
SDK=/home/happmaoo/Android/Sdk
BT=$SDK/build-tools/34.0.0
PLAT=$SDK/platforms/android-30/android.jar
APP=/home/happmaoo/temp/test/bleadv/app
B=$APP/build
MIN=21
TGT=30

STAMP=$(date +%s%N)
OBJ="$B/obj-$STAMP"
DEXDIR="$B/dex-$STAMP"
mkdir -p "$OBJ" "$DEXDIR" "$B/gen"

echo "[1/6] aapt2 compile"
"$BT/aapt2" compile --dir "$APP/res" -o "$B/res.zip"

echo "[2/6] aapt2 link"
"$BT/aapt2" link -o "$B/base.apk" -I "$PLAT" --manifest "$APP/AndroidManifest.xml" \
  --java "$B/gen" --min-sdk-version $MIN --target-sdk-version $TGT "$B/res.zip"

echo "[3/6] javac"
SRCS=$(find "$APP/src" -name '*.java')
if ! "$JDK/javac" -nowarn -encoding UTF-8 -source 8 -target 8 -bootclasspath "$PLAT" \
      -d "$OBJ" "$B/gen/com/myapp/mybleclient/R.java" $SRCS > "$B/javac.log" 2>&1; then
  echo "!! javac 失败，终止构建："
  grep -E "error:" -A3 "$B/javac.log" | head -30
  exit 1
fi
NCLS=$(find "$OBJ" -name '*.class' | wc -l)
for need in MainActivity BleService P Settings; do
  if [ ! -f "$OBJ/com/myapp/mybleclient/$need.class" ]; then
    echo "!! 产物缺少 $need.class，终止构建"; exit 1
  fi
done
echo "  编译产物：$NCLS 个 class（全新目录 $OBJ，无历史残留）"

echo "[4/6] d8"
"$JDK/java" -cp "$BT/lib/d8.jar" com.android.tools.r8.D8 --min-api $MIN --lib "$PLAT" \
  --output "$DEXDIR" $(find "$OBJ" -name '*.class')

echo "[5/6] 合包 classes.dex"
python3 - "$B/base.apk" "$DEXDIR/classes.dex" "$B/unsigned.apk" <<'PYEOF'
import sys, zipfile
base, dex, out = sys.argv[1], sys.argv[2], sys.argv[3]
zin = zipfile.ZipFile(base)
zout = zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED)
for it in zin.infolist():
    zout.writestr(it, zin.read(it.filename))
zout.write(dex, 'classes.dex')      # dex 未压缩存储，利于 ART 直接 mmap
zout.close(); zin.close()
PYEOF
"$BT/zipalign" -f 4 "$B/unsigned.apk" "$B/aligned.apk"

echo "[6/6] 签名"
KS="$B/debug.jks"
if [ ! -f "$KS" ]; then
  "$JDK/keytool" -genkeypair -keystore "$KS" -storetype JKS -alias androiddebugkey \
    -storepass android -keypass android -keyalg RSA -keysize 2048 -validity 10000 \
    -dname "CN=Android Debug,O=Android,C=US" 2>/dev/null
fi
"$BT/apksigner" sign --ks "$KS" --ks-pass pass:android --key-pass pass:android \
  --out "$APP/MyBleClient.apk" "$B/aligned.apk"
"$BT/apksigner" verify --print-certs "$APP/blecmd.apk" | head -2
ls -lh "$APP/MyBleClient.apk"
