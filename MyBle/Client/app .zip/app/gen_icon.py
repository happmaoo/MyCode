#!/usr/bin/env python3
"""生成 MyBleClient 的启动图标：圆角蓝底 + 白色蓝牙符文，纯 Python 输出 PNG。"""
import os, struct, zlib, math

APP = os.path.dirname(os.path.abspath(__file__))
SS = 4                      # 超采样倍数，用于抗锯齿
COLOR_BG = (14, 111, 222, 255)      # 蓝牙蓝
COLOR_BG2 = (10, 78, 168, 255)      # 底部稍深，做一点纵向渐变
COLOR_FG = (255, 255, 255, 255)

def seg_dist(px, py, a, b):
    ax, ay = a; bx, by = b
    vx, vy = bx - ax, by - ay
    wx, wy = px - ax, py - ay
    L2 = vx * vx + vy * vy
    t = 0.0 if L2 == 0 else max(0.0, min(1.0, (wx * vx + wy * vy) / L2))
    cx, cy = ax + t * vx, ay + t * vy
    return math.hypot(px - cx, py - cy)

def draw(size):
    """返回 size*size 的 RGBA 字节。坐标用 0~1 归一化。"""
    n = size * SS
    A = (0.50, 0.09); B = (0.50, 0.91)
    C = (0.76, 0.285); D = (0.76, 0.715)
    E = (0.24, 0.285); F = (0.24, 0.715)
    segs = [(A, B), (A, C), (C, F), (B, D), (B, E)]
    stroke = 0.062
    radius = 0.205                      # 圆角半径（占边长比例）
    buf = bytearray(n * n * 4)
    for j in range(n):
        y = (j + 0.5) / n
        for i in range(n):
            x = (i + 0.5) / n
            # 圆角矩形内判定
            dx = max(abs(x - 0.5) - (0.5 - radius), 0.0)
            dy = max(abs(y - 0.5) - (0.5 - radius), 0.0)
            inside = math.hypot(dx, dy) <= radius
            k = (j * n + i) * 4
            if not inside:
                buf[k:k + 4] = b'\x00\x00\x00\x00'
                continue
            # 背景：纵向轻微渐变
            bg = tuple(round(COLOR_BG[c] * (1 - 0.28 * y) + COLOR_BG2[c] * 0.28 * y)
                       for c in range(4))
            r = min(seg_dist(x, y, p, q) for p, q in segs)
            if r <= stroke:
                col = COLOR_FG
            elif r <= stroke + 1.6 / n:
                # 边缘做一次线性过渡
                t = (r - stroke) * n / 1.6
                col = tuple(round(COLOR_FG[c] * (1 - t) + bg[c] * t) for c in range(4))
            else:
                col = bg
            buf[k:k + 4] = bytes(col)
    # 降采样
    out = bytearray(size * size * 4)
    for j in range(size):
        for i in range(size):
            acc = [0, 0, 0, 0]
            for dj in range(SS):
                for di in range(SS):
                    k = (((j * SS + dj) * n) + (i * SS + di)) * 4
                    for c in range(4):
                        acc[c] += buf[k + c]
            m = SS * SS
            o = (j * size + i) * 4
            out[o:o + 4] = bytes([acc[0] // m, acc[1] // m, acc[2] // m, acc[3] // m])
    return bytes(out)

def png(path, size, data):
    def chunk(tag, payload):
        c = tag + payload
        return struct.pack('>I', len(payload)) + c + struct.pack('>I', zlib.crc32(c) & 0xffffffff)
    raw = b''.join(b'\x00' + data[(size * 4) * y:(size * 4) * (y + 1)] for y in range(size))
    ihdr = struct.pack('>IIBBBBB', size, size, 8, 6, 0, 0, 0)
    with open(path, 'wb') as f:
        f.write(b'\x89PNG\r\n\x1a\n')
        f.write(chunk(b'IHDR', ihdr))
        f.write(chunk(b'IDAT', zlib.compress(raw, 9)))
        f.write(chunk(b'IEND', b''))

if __name__ == '__main__':
    sizes = {'mdpi': 48, 'hdpi': 72, 'xhdpi': 96, 'xxhdpi': 144, 'xxxhdpi': 192}
    for d, px in sizes.items():
        outdir = os.path.join(APP, 'icons', 'mipmap-' + d)
        os.makedirs(outdir, exist_ok=True)
        img = draw(px)
        png(os.path.join(outdir, 'ic_launcher.png'), px, img)
        png(os.path.join(outdir, 'ic_launcher_round.png'), px, img)
        print('  mipmap-%s/ic_launcher.png  %dx%d' % (d, px, px))
    # 预览大图，便于直接查看效果
    png(os.path.join(APP, 'icon-preview.png'), 192, draw(192))
    print('  预览: app/icon-preview.png')
