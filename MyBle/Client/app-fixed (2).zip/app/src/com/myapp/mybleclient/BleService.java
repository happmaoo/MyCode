package com.myapp.mybleclient;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.content.Intent;
import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;

import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Date;
import java.util.Deque;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/**
 * 前台服务 = 唯一的 BLE 连接引擎。
 *
 * 原先把整套 GATT 状态机放在 MainActivity 里，界面被销毁重建（切后台被回收、
 * 从通知栏重进、旋转屏幕）时连接随之丢失，还可能出现"第二个实例再连一条"的问题。
 * 现在所有连接状态都住在 Service 里：
 *   - Activity 无论重建多少次，都只是 bind 上来"订阅状态"，不碰连接；
 *   - Activity 销毁不再断链、不再停服务；
 *   - 重建后 setUi() 会把当前状态（状态行/电量信号/按钮/日志）整包推回去，
 *     界面文字自动恢复，不会闪成"未连接"再等回调。
 * 引擎全部事件都收敛到主线程 Handler 上串行执行，与原来 runOnUiThread 的单线程语义一致。
 */
public class BleService extends Service {

    static final int NOTIF_ID = 0x42;
    static final String CH_ID = "blecmd_conn";

    static final UUID SVC_CMD = UUID.fromString("8e7a1f01-2b3c-4d5e-6f70-8192a3b4c5d6");
    static final UUID CH_CMD  = UUID.fromString("8e7a1f03-2b3c-4d5e-6f70-8192a3b4c5d6");
    static final UUID CH_RES  = UUID.fromString("8e7a1f04-2b3c-4d5e-6f70-8192a3b4c5d6");
    static final UUID CH_AUTH = UUID.fromString("8e7a1f05-2b3c-4d5e-6f70-8192a3b4c5d6");
    static final UUID SVC_BAS = UUID.fromString("0000180f-0000-1000-8000-00805f9b34fb");
    static final UUID CH_BATT = UUID.fromString("00001a19-0000-1000-8000-00805f9b34fb");
    static final UUID CCCD    = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
    static final Charset UTF8 = Charset.forName("UTF-8");

    /** 界面回调：Activity 绑定后注册；重建后重新注册并收到全量快照 */
    public interface Ui {
        void onInfo(String s);        // 状态行 tvInfo
        void onBatt(String s);        // 电量/信号行 tvBatt
        void onLog(String s);         // 追加一条事件/结果块（已含时间戳格式）
        void onLogReset(String s);    // 整体重设日志区（重绑定时回放 logBuf / 清空）
        void onBtn(String text, boolean enabled); // Connect 按钮状态
        void onToast(String s);
    }

    public class LocalBinder extends Binder {
        public BleService getService() { return BleService.this; }
    }
    private final LocalBinder binder = new LocalBinder();
    @Override public IBinder onBind(Intent intent) { return binder; }

    volatile Ui uiCb;                                   // 当前界面（唯一）
    final Handler th = new Handler(Looper.getMainLooper()); // 引擎单线程

    // ---- 全量状态快照：重建的界面靠它一次性恢复文字 ----
    String curInfo = "未连接";
    String curBatt = "";   // 未连接时不显示电量信号行
    String btnText = "Connect";
    boolean btnEnabled = true;
    final ArrayDeque<String> logBuf = new ArrayDeque<String>(); // 日志环形缓冲，重进回放
    static final int LOG_MAX = 400;

    // ------------------------------------------------------------- 引擎状态
    BluetoothAdapter adapter;
    BluetoothManager btManager;
    BluetoothGatt gatt;
    BluetoothDevice curDevice;
    BluetoothGattCharacteristic cBatt, cCmd, cRes, cAuth;

    final SimpleDateFormat ts = new SimpleDateFormat("HH:mm:ss", Locale.US);
    final Deque<W> wq = new ArrayDeque<W>();
    boolean writing = false;
    /** 结果累积用字节缓冲：多字节 UTF-8 字符（如汉字 3 字节）可跨帧，末片到齐后一次性解码 */
    final java.io.ByteArrayOutputStream rx = new java.io.ByteArrayOutputStream();

    int step = 0;              // 0 未开始 1 读电量 2 订阅电量 3 订阅RES 4 鉴权 9 就绪
    int lastBattery = -1;
    int lastRssi = 0;
    long lastRssiOkAt = 0;
    int rssiBusy = 0;
    int hbTicks = 0;
    boolean linkUp = false;
    boolean connecting = false;
    boolean scanning = false;
    boolean waitingResult = false;
    boolean resSubscribed = false;   // RES 的 CCCD 是否订阅成功（没订阅就别发命令）
    PowerManager.WakeLock wake;      // 可选：熄屏保活（设置 keep_wake 开启才持有）
    String want = "";
    String mtuText = "";
    int curMtu = 23;               // 协商后的 MTU；命令超长分片写入时按 MTU-3 切

    /** 一条待写的 (特征, 内容)：AUTH 与 CMD 共用写队列但目标不同 */
    static final class W {
        final BluetoothGattCharacteristic ch;
        final byte[] v;
        W(BluetoothGattCharacteristic ch, byte[] v) { this.ch = ch; this.v = v; }
    }

    // ------------------------------------------------------------------ 定时器

    final Runnable scanTimeout = new Runnable() {
        @Override public void run() {
            if (connecting || linkUp) return;
            stopScan();
            info("没扫到：" + want + "（确认服务端在跑、广播名一致）");
            setBtn("Connect", true);
        }
    };

    /** 初始化看门狗：15 秒走不到就绪就释放连接（外设被重启时客户端会卡在发现服务） */
    final Runnable readyTimeout = new Runnable() {
        @Override public void run() {
            if (step >= 9 || gatt == null) return;
            info("初始化超时（卡在步骤 " + step + "）—— 已释放连接，请重新 Connect");
            logEvent("初始化超时 step=" + step + "：某个 ATT 请求没回调，或外设进程被重启过");
            hardClose();
        }
    };

    /** 半片兜底：4 秒没等到后续片，把已收到的半包显示出来（字节缓冲整体解码，跨帧字符不坏） */
    final Runnable chunkTimeout = new Runnable() {
        @Override public void run() {
            if (rx.size() == 0) return;
            String half = new String(rx.toByteArray(), UTF8);
            rx.reset();
            appendResult(half + "\n⚠ 分片不完整（4s 内没等到后续片，已显示半包）");
            info(linkUp ? readyText() + "（上一结果不完整）" : "已断开");
        }
    };

    /** 零片兜底：Run 之后超时没收到任何片就明确提示（时长可在设置页调，0=关闭）。
     *  只提示、不自动重连——要不要重连由用户决定；真断链由心跳检测并按"自动连接"开关处理。 */
    final Runnable noChunkTimeout = new Runnable() {
        @Override public void run() {
            if (!waitingResult || rx.size() > 0) return;
            waitingResult = false;
            long ms = P.zeroChunkMs(BleService.this);
            appendResult("⚠ " + (ms / 1000.0) + "s 内没收到任何通知片：服务端未发出，或订阅/链路状态已失效"
                    + "（服务端日志会写明 PUMP 跳过的原因；时长可在设置页调整）");
            info(linkUp ? readyText() + "（无结果返回）" : "已断开");
        }
    };

    /**
     * 单一心跳：链路存在期间任何分支都在 finally 里自我续期。
     * 职责：按需 readRemoteRssi、刷新电量/信号行、链路新鲜度看门狗。
     * gatt 已彻底释放时心跳自动终止——否则会每轮空报 linkAlive=false 刷屏。
     */
    final Runnable heartbeat = new Runnable() {
        @Override public void run() {
            if (gatt == null) return;   // 链路已完全释放：心跳到此为止，不再空转
            int iv = Math.max(1, P.rssiSec(BleService.this));
            try {
                hbTicks++;
                if (!linkAlive()) {
                    boolean auto = P.autoConnect(BleService.this);
                    info(auto ? "链路已断开（协议栈未报告 GATT 连接）—— 重连中"
                              : "链路已断开（协议栈未报告 GATT 连接）—— 请手动重连");
                    logEvent("心跳 #" + hbTicks + "：linkAlive=false → 释放并复位按钮");
                    hardClose();
                    if (auto) th.postDelayed(autoConnectTask, 3000);
                    return;
                }
                long silent = System.currentTimeMillis() - lastRssiOkAt;
                long lim = P.rssiSilentSec(BleService.this) * 1000L;
                if (lim > 0 && (lastRssiOkAt == 0 || silent > lim)) {
                    boolean auto = P.autoConnect(BleService.this);
                    info(auto ? "链路疑似已失效（RSSI 静默 " + (silent / 1000) + "s）—— 重连中"
                              : "链路疑似已失效（RSSI 静默 " + (silent / 1000) + "s）—— 请手动重连");
                    logEvent("心跳 #" + hbTicks + "：RSSI 静默 " + (silent / 1000)
                            + "s（阈值 " + (lim / 1000) + "s），readRemoteRssi 被拒 "
                            + rssiBusy + " 次 → 释放");
                    hardClose();
                    if (auto) th.postDelayed(autoConnectTask, 3000);
                    return;
                }
                boolean ok = false;
                try { ok = gatt.readRemoteRssi(); } catch (Throwable ignored) { }
                if (!ok) {
                    rssiBusy++;
                    if (rssiBusy == 1 || rssiBusy % 10 == 0) {
                        logEvent("readRemoteRssi 被拒 " + rssiBusy + " 次（链路上有其它操作在途）");
                    }
                }
                refreshBattLine();
            } catch (Throwable t) {
                logEvent("心跳异常：" + t);
            } finally {
                th.postDelayed(this, iv * 1000L);      // 唯一续期点，永不漏
            }
        }
    };

    final Runnable autoConnectTask = new Runnable() {
        @Override public void run() { if (gatt == null && !linkUp) beginConnect(P.server(BleService.this)); }
    };

    final Runnable retryDrain = new Runnable() {
        @Override public void run() { drain(); }
    };

    // ---------------------------------------------------------------- 生命周期

    @Override
    public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null && nm.getNotificationChannel(CH_ID) == null) {
                NotificationChannel ch = new NotificationChannel(CH_ID, "BLE 连接",
                        NotificationManager.IMPORTANCE_LOW);
                ch.setShowBadge(false);
                nm.createNotificationChannel(ch);
            }
        }
        btManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        adapter = (btManager == null) ? null : btManager.getAdapter();
        if (adapter == null) info("本机不支持蓝牙，或蓝牙服务不可用");
    }

    // 注意：onDestroy 只在服务真正被销毁时执行（用户"断开并释放"、系统杀进程）。
    // Activity 销毁/重建不会走到这里 —— 连接与通知因此得以存活。

    @Override
    public void onDestroy() {
        super.onDestroy();
        uiCb = null;
        releaseWake();
        removeAllTimers();
        stopScan();
        if (gatt != null) {
            try { gatt.disconnect(); gatt.close(); } catch (Throwable ignored) { }
            gatt = null;
        }
        stopForeground(true);
    }

    void removeAllTimers() {
        th.removeCallbacks(scanTimeout);
        th.removeCallbacks(readyTimeout);
        th.removeCallbacks(chunkTimeout);
        th.removeCallbacks(noChunkTimeout);
        th.removeCallbacks(heartbeat);
        th.removeCallbacks(autoConnectTask);
        th.removeCallbacks(retryDrain);
    }

    // ------------------------------------------------------------- 对 UI 的接口

    /** 绑定（或重建后重绑）时调用：注册回调并整包回放当前状态，界面文字立即恢复 */
    public void setUi(final Ui u) {
        uiCb = u;
        if (u == null) return;
        th.post(new Runnable() {
            @Override public void run() {
                if (uiCb != u) return;
                try {
                    u.onInfo(curInfo);
                    u.onBatt(curBatt);
                    u.onBtn(btnText, btnEnabled);
                    StringBuilder sb = new StringBuilder();
                    for (String s : logBuf) sb.append(s);
                    u.onLogReset(sb.toString());
                } catch (Throwable ignored) { }
            }
        });
    }

    public void clearUi(Ui u) {
        if (uiCb == u) uiCb = null;
    }

    /** 由 Activity 在权限检查通过后调用；引擎串到主线程执行 */
    public void connect(final String name) {
        th.post(new Runnable() {
            @Override public void run() { beginConnect(name); }
        });
    }

    /** 自动连接入口（设置里开了自动连接时，界面 onResume / 重绑定时触发一次） */
    public void ensureAutoConnect() {
        th.post(new Runnable() {
            @Override public void run() {
                if (!P.autoConnect(BleService.this)) return;
                if (gatt != null || linkUp || connecting || scanning) return;
                logEvent("自动连接：" + P.server(BleService.this));
                beginConnect(P.server(BleService.this));
            }
        });
    }

    /** 发命令；就绪门槛在引擎里统一把关，拒绝原因通过 toast 回给界面 */
    public void run(final String cmd) {
        th.post(new Runnable() {
            @Override public void run() {
                String c = cmd == null ? "" : cmd.trim();
                if (c.length() == 0) { toast("命令为空"); return; }
                if (gatt == null || cCmd == null) { toast("还没连上/没就绪"); return; }
                // 关键门槛：鉴权与订阅都没完成就发命令，必然被服务端拒绝且结果回不来
                if (step < 9) { toast("初始化未完成（第 " + step + " 步），稍等再发"); return; }
                if (!resSubscribed) { toast("RES 通知未订阅成功，命令结果收不到"); return; }
                setConnPriority(BluetoothGatt.CONNECTION_PRIORITY_BALANCED); // 交互期提速
                appendResult("$ " + c);
                waitingResult = true;
                th.removeCallbacks(noChunkTimeout);
                int zc = P.zeroChunkMs(BleService.this);
                if (zc > 0) th.postDelayed(noChunkTimeout, zc);   // 0=关闭零片提示
                // BLE 单次 write 载荷上限 = MTU-3。超长命令按 (MTU-4)/片 分片：
                // 首字节 '>' = 还有后续，'<' = 末片；单帧命令保持原样（兼容旧服务端）
                byte[] raw = c.getBytes(UTF8);
                int maxW = Math.max(20, curMtu - 3);
                if (raw.length <= maxW) {
                    wq.add(new W(cCmd, raw));
                } else {
                    int per = maxW - 1;                    // 每片首字节留给 > / < 标记
                    int frags = (raw.length + per - 1) / per;
                    logEvent("命令 " + raw.length + " 字节超 MTU（" + maxW + "），分 " + frags + " 片发送");
                    for (int off = 0; off < raw.length; off += per) {
                        int len = Math.min(per, raw.length - off);
                        byte[] piece = new byte[len + 1];
                        piece[0] = (byte) ((off + len >= raw.length) ? '<' : '>');
                        System.arraycopy(raw, off, piece, 1, len);
                        wq.add(new W(cCmd, piece));
                    }
                }
                drain();
            }
        });
    }

    /** 手动断开/释放：关链路、撤定时器、撤通知、停服务（Activity 销毁不走这里） */
    public void userRelease() {
        th.post(new Runnable() {
            @Override public void run() {
                removeAllTimers();
                stopScan();
                connecting = false;
                if (gatt != null) {
                    try { gatt.disconnect(); gatt.close(); } catch (Throwable ignored) { }
                    gatt = null;
                }
                linkUp = false;
                curDevice = null;
                resetState();
                setBattIdle();
                info("已断开（手动）");
                setBtn("Connect", true);
                updateNotif("未连接");
                stopForeground(true);
                stopSelf();
            }
        });
    }

    /** 界面点"清空"：视图和缓冲一起清，否则重进后又被回放出来 */
    public void clearLog() {
        th.post(new Runnable() {
            @Override public void run() {
                logBuf.clear();
                Ui u = uiCb;
                if (u != null) { try { u.onLogReset(""); } catch (Throwable ignored) { } }
            }
        });
    }

    // ---------------------------------------------------------------- 扫描连接

    void beginConnect(String name) {
        if (name == null || name.trim().length() == 0) { toast("请输入广播名"); return; }
        want = name.trim();
        if (adapter == null || !adapter.isEnabled()) { info("蓝牙未开启，请先打开蓝牙"); setBtn("Connect", true); return; }
        startScan();
    }

    void startScan() {
        setBtn("扫描中…", false);
        connecting = false;
        goForeground("扫描/连接 " + want + " …");
        final BluetoothLeScanner sc = adapter.getBluetoothLeScanner();
        if (sc == null) { info("拿不到 BLE 扫描器"); setBtn("Connect", true); return; }
        List<ScanFilter> fs = new ArrayList<ScanFilter>();
        fs.add(new ScanFilter.Builder().setDeviceName(want).build());
        ScanSettings st = new ScanSettings.Builder()
                .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build();
        info("扫描：" + want + " …");
        scanning = true;
        try {
            sc.startScan(fs, st, scanCb);
            th.postDelayed(scanTimeout, 12000);
        } catch (SecurityException e) {
            scanning = false;
            info("缺少权限，无法扫描：" + e.getMessage());
            setBtn("Connect", true);
        }
    }

    void stopScan() {
        scanning = false;
        try {
            if (adapter == null) return;
            BluetoothLeScanner sc = adapter.getBluetoothLeScanner();
            if (sc != null) sc.stopScan(scanCb);
        } catch (Throwable ignored) { }
    }

    final ScanCallback scanCb = new ScanCallback() {
        @Override public void onScanResult(int callbackType, final ScanResult result) {
            th.post(new Runnable() {
                @Override public void run() {
                    BluetoothDevice d = result.getDevice();
                    String name = safeName(d, result);
                    if (name == null || !name.equalsIgnoreCase(want)) return;
                    connecting = true;
                    scanning = false;
                    th.removeCallbacks(scanTimeout);
                    stopScan();
                    // 原始广播数据（ADV payload，hex）：裁掉末尾补零，附有效字节数
                    byte[] adv = null;
                    try {
                        if (result.getScanRecord() != null) adv = result.getScanRecord().getBytes();
                    } catch (Throwable ignored) { }
                    String advHex = "(空)";
                    if (adv != null && adv.length > 0) {
                        int end = adv.length;                       // 裁掉末尾连续的 00 填充
                        while (end > 0 && adv[end - 1] == 0) end--;
                        if (end == 0) end = adv.length;             // 全 0 时原样显示
                        advHex = "0x" + hex(java.util.Arrays.copyOf(adv, end))
                                + " (" + end + " Byte)";
                    }
                    logEvent("发现目标 " + d.getAddress() + " RSSI " + result.getRssi()
                            + "dBm，广播数据 " + advHex);
                    connectDevice(d, result.getRssi());
                }
            });
        }

        @Override public void onScanFailed(final int errorCode) {
            th.post(new Runnable() {
                @Override public void run() {
                    scanning = false;
                    info("扫描失败 code=" + errorCode + "（多为蓝牙/定位未就绪）");
                    th.removeCallbacks(scanTimeout);
                    setBtn("Connect", true);
                }
            });
        }
    };

    String safeName(BluetoothDevice d, ScanResult r) {
        try {
            String n = d.getName();
            if (n != null) return n;
        } catch (Throwable ignored) { }
        try {
            if (r.getScanRecord() != null) return r.getScanRecord().getDeviceName();
        } catch (Throwable ignored) { }
        return null;
    }

    /** 字节数组 → 大写十六进制串 */
    static String hex(byte[] b) {
        if (b == null || b.length == 0) return "";
        StringBuilder sb = new StringBuilder(b.length * 2);
        for (byte x : b) sb.append(String.format("%02X", x));
        return sb.toString();
    }

    /** 就绪状态文案：显示已连接对端的 MAC 地址 */
    String readyText() {
        return "已连接 " + ((curDevice != null) ? curDevice.getAddress() : want);
    }

    void connectDevice(BluetoothDevice d, final int rssi) {
        if (gatt != null) { try { gatt.close(); } catch (Throwable ignored) { } gatt = null; }
        curDevice = d;
        resetState();
        lastRssi = rssi;
        refreshBattLine();
        setBtn("连接中…", false);
        info("连接 " + d.getAddress() + "（RSSI " + rssi + "）…");
        goForeground("连接 " + want + " …");
        th.postDelayed(readyTimeout, 15000);
        if (Build.VERSION.SDK_INT >= 23) {
            gatt = d.connectGatt(this, false, gattCb, BluetoothDevice.TRANSPORT_LE);
        } else {
            gatt = d.connectGatt(this, false, gattCb);
        }
    }

    /** 强制释放：撤定时器、清状态、复位按钮（不断开链路以外的资源由调用方决定） */
    /** 强制释放：撤定时器、关链路、清状态、复位按钮。
     *  必须真正 disconnect+close，否则留下"半清理"状态：
     *  gatt 悬着、curDevice 已空 → linkAlive() 永远 false → 心跳每轮空报刷屏。 */
    void hardClose() {
        linkUp = false;
        connecting = false;
        th.removeCallbacks(readyTimeout);
        th.removeCallbacks(chunkTimeout);
        th.removeCallbacks(noChunkTimeout);
        th.removeCallbacks(heartbeat);
        if (gatt != null) {
            try { gatt.disconnect(); gatt.close(); } catch (Throwable ignored) { }
            gatt = null;
        }
        curDevice = null;
        resetState();
        setBattIdle();
        info("未连接");
        updateNotif("未连接");
        setBtn("Connect", true);
        releaseWake();
    }

    void resetState() {
        cBatt = null; cCmd = null; cRes = null; cAuth = null;
        wq.clear();
        writing = false;
        rx.reset();
        step = 0;
        mtuText = "";
        curMtu = 23;
        lastBattery = -1;
        waitingResult = false;
        resSubscribed = false;
    }

    /** 链路存活只问协议栈，不信业务 flag，也不受迟到事件摆布 */
    boolean linkAlive() {
        if (gatt == null) return false;
        try {
            if (btManager != null && curDevice != null) {
                return btManager.getConnectionState(curDevice, BluetoothProfile.GATT)
                        == BluetoothProfile.STATE_CONNECTED;
            }
        } catch (Throwable ignored) { }
        return linkUp;
    }

    // ------------------------------------------------------------- GATT 客户端

    final BluetoothGattCallback gattCb = new BluetoothGattCallback() {
        @Override public void onConnectionStateChange(final BluetoothGatt g, final int status, final int newState) {
            th.post(new Runnable() {
                @Override public void run() { onConnState(g, status, newState); }
            });
        }

        @Override public void onServicesDiscovered(final BluetoothGatt g, final int status) {
            th.post(new Runnable() {
                @Override public void run() { onSvcDiscovered(g, status); }
            });
        }

        @Override public void onMtuChanged(final BluetoothGatt g, final int mtu, final int status) {
            th.post(new Runnable() {
                @Override public void run() { onMtu(g, mtu, status); }
            });
        }

        @Override public void onCharacteristicRead(final BluetoothGatt g,
                                                   final BluetoothGattCharacteristic ch, final int status) {
            th.post(new Runnable() {
                @Override public void run() { onCharRead(g, ch, status); }
            });
        }

        @Override public void onCharacteristicWrite(final BluetoothGatt g,
                                                    final BluetoothGattCharacteristic ch, final int status) {
            th.post(new Runnable() {
                @Override public void run() { onCharWrite(g, ch, status); }
            });
        }

        @Override public void onDescriptorWrite(final BluetoothGatt g, final BluetoothGattDescriptor d, final int status) {
            th.post(new Runnable() {
                @Override public void run() { onDescWrite(g, d, status); }
            });
        }

        @Override public void onReadRemoteRssi(final BluetoothGatt g, final int rssi, final int status) {
            th.post(new Runnable() {
                @Override public void run() { onRssi(g, rssi, status); }
            });
        }

        @Override public void onCharacteristicChanged(final BluetoothGatt g,
                                                      final BluetoothGattCharacteristic ch) {
            th.post(new Runnable() {
                @Override public void run() { onNotify(g, ch); }
            });
        }
    };

    void onConnState(BluetoothGatt g, int status, int newState) {
        if (g != gatt) { logEvent("忽略旧 gatt 对象的连接事件 state=" + newState); return; }
        if (newState == BluetoothProfile.STATE_CONNECTED) {
            linkUp = true;
            goForeground("已连接 " + want + "，初始化…");
            acquireWake();
            setBtn("已连接", false);
            info("已连接，发现服务…");
            g.discoverServices();
        } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
            if (status != BluetoothGatt.GATT_SUCCESS && status != 19) {
                info("连接中断 status=" + status + "（外设可能被重启）");
            } else {
                info("已断开");
            }
            th.removeCallbacks(readyTimeout);
            th.removeCallbacks(heartbeat);
            updateNotif("已断开");
            setBtn("Connect", true);     // 无条件复位
            try { g.close(); } catch (Throwable ignored) { }
            gatt = null;
            curDevice = null;
            linkUp = false;
            connecting = false;
            resetState();
            setBattIdle();
            releaseWake();
            stopForeground(true);        // 链路没了，通知也撤下
            if (P.autoConnect(this)) th.postDelayed(autoConnectTask, 4000);
        }
    }

    void onSvcDiscovered(BluetoothGatt g, int status) {
        if (g != gatt) return;
        BluetoothGattService cmd = null, bas = null;
        try {
            cmd = g.getService(SVC_CMD);
            bas = g.getService(SVC_BAS);
        } catch (Throwable t) { }
        if (cmd != null) {
            cCmd  = cmd.getCharacteristic(CH_CMD);
            cRes  = cmd.getCharacteristic(CH_RES);
            cAuth = cmd.getCharacteristic(CH_AUTH);
        }
        if (bas != null) cBatt = bas.getCharacteristic(CH_BATT);
        logEvent("服务发现：BAS=" + (bas != null) + " 1A19=" + (cBatt != null)
                + " cmd=" + (cmd != null) + " CMD=" + (cCmd != null)
                + " RES=" + (cRes != null) + " AUTH=" + (cAuth != null));
        if (cCmd == null && cBatt == null) {
            th.removeCallbacks(readyTimeout);
            info("没发现预期特征——确认连的是 Rolex，且服务端已注册服务");
            return;
        }
        g.requestMtu(517);
    }

    void onMtu(BluetoothGatt g, int mtu, int status) {
        if (g != gatt) return;
        curMtu = mtu;
        mtuText = "MTU " + mtu;
        logEvent("MTU 协商完成 " + mtu + "（单片可用 " + Math.max(1, mtu - 4) + " 字节）");
        step = 1;
        runStep();
    }

    void onCharRead(BluetoothGatt g, BluetoothGattCharacteristic ch, int status) {
        if (g != gatt) return;
        if (CH_BATT.equals(ch.getUuid()) && status == BluetoothGatt.GATT_SUCCESS) {
            showBattery(ch.getValue());
        }
        step = 2;
        runStep();
    }

    void onCharWrite(BluetoothGatt g, BluetoothGattCharacteristic ch, int status) {
        if (g != gatt) return;
        writing = false;
        if (status != BluetoothGatt.GATT_SUCCESS) {
            info("写失败 status=" + status);
            logEvent("写 " + shortOf(ch.getUuid()) + " 失败 status=" + status);
        }
        drain();
    }

    void onDescWrite(BluetoothGatt g, BluetoothGattDescriptor d, int status) {
        if (g != gatt) return;
        if (status != BluetoothGatt.GATT_SUCCESS) {
            info("订阅失败 status=" + status);
            logEvent("订阅 CCCD 失败 status=" + status + "（服务端可能没声明 NOTIFY）");
        } else {
            if (CH_RES.equals(uuidOf(d))) resSubscribed = true;
            logEvent("订阅成功：" + shortOf(uuidOf(d))
                    + (CH_RES.equals(uuidOf(d)) ? "（结果通道已就绪）" : ""));
        }
        step = step + 1;
        runStep();
    }

    void onRssi(BluetoothGatt g, int rssi, int status) {
        if (g != gatt) return;
        if (status == BluetoothGatt.GATT_SUCCESS) {
            lastRssi = rssi;
            lastRssiOkAt = System.currentTimeMillis();
            refreshBattLine();
        } else {
            logEvent("readRemoteRssi 返回 status=" + status);
        }
    }

    void onNotify(BluetoothGatt g, BluetoothGattCharacteristic ch) {
        if (g != gatt) return;
        byte[] v = ch.getValue();
        if (v == null || v.length == 0) return;
        if (CH_BATT.equals(ch.getUuid())) {
            showBattery(v);
        } else if (CH_RES.equals(ch.getUuid())) {
            handleChunk(v);
        }
    }

    static UUID uuidOf(BluetoothGattDescriptor d) {
        try {
            BluetoothGattCharacteristic c = d.getCharacteristic();
            return c == null ? CCCD : c.getUuid();
        } catch (Throwable t) { return CCCD; }
    }

    /** 串起来：读电量 -> 订阅电量 -> 订阅 RES -> 写 AUTH */
    void runStep() {
        BluetoothGatt g = gatt;
        if (g == null) return;
        if (step == 1) { if (cBatt != null) { g.readCharacteristic(cBatt); return; } step = 2; }
        if (step == 2) { if (cBatt != null && enableNotify(cBatt)) return; step = 3; }
        if (step == 3) { if (cRes != null && enableNotify(cRes)) return; step = 4; }
        if (step == 4) {
            if (cAuth != null) {
                String key = P.psk(this).trim();
                logEvent("写 AUTH（密钥 " + key.length() + " 字符）…");
                wq.add(new W(cAuth, key.getBytes(UTF8)));
                drain();
            }
            step = 9;
        }
        if (step == 9) {
            th.removeCallbacks(readyTimeout);
            lastRssiOkAt = System.currentTimeMillis();
            th.removeCallbacks(heartbeat);
            th.postDelayed(heartbeat, 1000);
            setConnPriority(BluetoothGatt.CONNECTION_PRIORITY_LOW_POWER); // 空闲省电
            info(readyText());
            updateNotif(readyText());
            logEvent("就绪（" + readyText() + "）：" + (cBatt != null ? "Battery Level 可读/可订阅；" : "无电池服务；")
                    + (cCmd != null ? "命令通道可用" : "无命令通道"));
        }
    }

    /**
     * 连接参数省电：就绪/空闲时请求 LOW_POWER（连接间隔拉长到 ~150-225ms，射频少醒），
     * 发命令前临时升 BALANCED（~40ms）保住交互延迟，结果收完再降回去。
     * 服务端是外设端，无法自己请求连接参数，只能靠客户端这头提。
     */
    void setConnPriority(int mode) {
        try {
            if (gatt != null) gatt.requestConnectionPriority(mode);
        } catch (Throwable ignored) { }
    }

    // ------------------------------------------------------------ 熄屏保活（可选）

    /** 设置开启时，连接期间持有 CPU 唤醒锁：防止熄屏后 AP 休眠导致 ATT 停摆/回调丢失 */
    void acquireWake() {
        if (!P.keepWake(this) || wake != null) return;
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (pm == null) return;
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "blecmd:conn");
            wake.setReferenceCounted(false);
            wake.acquire();
            logEvent("已持有 CPU 唤醒锁（熄屏保活，耗电换稳定）");
        } catch (Throwable t) {
            logEvent("唤醒锁获取失败：" + t);
        }
    }

    void releaseWake() {
        try {
            if (wake != null && wake.isHeld()) wake.release();
        } catch (Throwable ignored) { }
        wake = null;
    }

    boolean enableNotify(BluetoothGattCharacteristic ch) {
        if (ch == null || gatt == null) return false;
        if (!gatt.setCharacteristicNotification(ch, true)) {
            logEvent("setCharacteristicNotification 失败：" + shortOf(ch.getUuid()));
            return false;
        }
        BluetoothGattDescriptor cd = ch.getDescriptor(CCCD);
        if (cd == null) {
            logEvent(shortOf(ch.getUuid()) + " 没有 CCCD，只能读不能通知");
            return false;
        }
        cd.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
        return gatt.writeDescriptor(cd);
    }

    // ------------------------------------------------------ 电量 / 信号 / 结果

    void showBattery(byte[] v) {
        if (v == null || v.length == 0) { logEvent("电量返回空"); return; }
        lastBattery = v[0] & 0xFF;
        refreshBattLine();
    }

    void refreshBattLine() {
        final String line;
        if (!linkUp) {
            line = "";          // 未连接/已断开/连接中：电量信号行整体不显示
        } else {
            line = "电量: " + (lastBattery < 0 ? "—" : lastBattery + "%")
                    + "   信号: " + (lastRssi == 0 ? "—" : lastRssi + " dBm")
                    + "   " + ts.format(new Date());
        }
        curBatt = line;
        Ui u = uiCb;
        if (u != null) { try { u.onBatt(line); } catch (Throwable ignored) { } }
        updateNotif((lastBattery < 0 ? "" : lastBattery + "%  ")
                + (lastRssi == 0 ? "" : lastRssi + " dBm"));
    }

    void setBattIdle() {
        lastBattery = -1;
        lastRssi = 0;
        refreshBattLine();
    }

    /** 服务端分片协议：'+' 还有后续，'-' 末片，'!' 拒绝或错误。
     *  帧内 payload 追加进字节缓冲，'-' 末片到齐后一次性 UTF-8 解码——
     *  多字节字符跨帧也不会坏（v1.x 逐帧解码会把跨帧汉字切成 �）。 */
    void handleChunk(byte[] v) {
        waitingResult = false;
        th.removeCallbacks(noChunkTimeout);
        char mark = (char) (v[0] & 0xFF);
        if (mark == '+') {
            try { rx.write(v, 1, v.length - 1); } catch (Throwable ignored) { }
            th.removeCallbacks(chunkTimeout);
            th.postDelayed(chunkTimeout, 4000);
            info("接收中… 已 " + rx.size() + " 字节");
        } else if (mark == '-') {
            th.removeCallbacks(chunkTimeout);
            try { rx.write(v, 1, v.length - 1); } catch (Throwable ignored) { }
            String whole = new String(rx.toByteArray(), UTF8);
            rx.reset();
            appendResult(whole);
            logEvent("接收完成 " + whole.length() + " 字符（末片）");
            if ("auth:ok".equals(whole.trim())) rememberKey();
            setConnPriority(BluetoothGatt.CONNECTION_PRIORITY_LOW_POWER); // 回到省电档
            if (linkUp) info(readyText());
        } else if (mark == '!') {
            th.removeCallbacks(chunkTimeout);
            if (rx.size() > 0) { appendResult(new String(rx.toByteArray(), UTF8)); rx.reset(); }
            appendResult("✗ " + new String(v, 1, v.length - 1, UTF8));
        } else {
            try { rx.write(v, 0, v.length); } catch (Throwable ignored) { }
            appendResult(new String(rx.toByteArray(), UTF8));
            rx.reset();
        }
    }

    void drain() {
        if (writing || wq.isEmpty() || gatt == null) return;
        W w = wq.poll();
        writing = true;
        w.ch.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
        w.ch.setValue(w.v);
        if (!gatt.writeCharacteristic(w.ch)) {
            writing = false;
            wq.addFirst(w);
            info("写请求提交失败（上一条还没完成）");
            logEvent("写 " + shortOf(w.ch.getUuid()) + " 提交失败，400ms 后重试");
            th.postDelayed(retryDrain, 400);
        }
    }

    void rememberKey() {
        String k = P.psk(this).trim();
        if (k.length() == 0) return;
        P.savePsk(this, k);
        logEvent("密钥已记住（下次启动自动填入，APK 内不内置密钥）");
    }

    // ------------------------------------------------------------------ 显示

    void info(String s) {
        curInfo = s;
        Ui u = uiCb;
        if (u != null) { try { u.onInfo(s); } catch (Throwable ignored) { } }
    }

    void appendResult(String text) {
        addLog("──── " + ts.format(new Date()) + " ────\n" + text + "\n\n");
    }

    void logEvent(String s) {
        addLog("· " + ts.format(new Date()) + "  " + s + "\n");
    }

    void addLog(String s) {
        logBuf.addLast(s);
        while (logBuf.size() > LOG_MAX) logBuf.pollFirst();
        Ui u = uiCb;
        if (u != null) { try { u.onLog(s); } catch (Throwable ignored) { } }
    }

    void setBtn(String text, boolean enabled) {
        btnText = text;
        btnEnabled = enabled;
        Ui u = uiCb;
        if (u != null) { try { u.onBtn(text, enabled); } catch (Throwable ignored) { } }
    }

    void toast(String s) {
        Ui u = uiCb;
        if (u != null) { try { u.onToast(s); } catch (Throwable ignored) { } }
        else logEvent(s);
    }

    // ------------------------------------------------------------ 前台通知

    /** 连接开始就进入前台：比原来"连上才挂通知"更稳，后台扫描期间进程也不会被降级 */
    void goForeground(String text) {
        try {
            startForeground(NOTIF_ID, build(text));
        } catch (Throwable t) {
            logEvent("前台通知失败：" + t);
        }
    }

    void updateNotif(String text) {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(NOTIF_ID, build(text));
        } catch (Throwable ignored) { }
    }

    Notification build(String text) {
        Intent open = new Intent(this, MainActivity.class);
        // 点通知是"回到已有实例"（singleTop + CLEAR_TOP|SINGLE_TOP）：
        // 不新建 Activity；就算 Task 已被回收导致重建，重建后也只是重新 bind，
        // 从本服务拿全量状态，不会发起第二条连接。
        open.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open,
                Build.VERSION.SDK_INT >= 23
                        ? (PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE)
                        : PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = (Build.VERSION.SDK_INT >= 26)
                ? new Notification.Builder(this, CH_ID)
                : new Notification.Builder(this);
        b.setContentTitle("MyBleClient")
         .setContentText(text == null || text.length() == 0 ? "未连接" : text)
         .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
         .setContentIntent(pi)
         .setOngoing(true);
        if (Build.VERSION.SDK_INT >= 24) b.setShowWhen(false);
        return b.build();
    }

    static String shortOf(UUID u) {
        String s = u.toString();
        return s.length() >= 8 ? s.substring(4, 8) : s;
    }
}
