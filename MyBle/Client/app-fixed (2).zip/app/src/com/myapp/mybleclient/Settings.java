package com.myapp.mybleclient;

import android.app.Activity;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

/** 设置页：广播名 / 密钥 / RSSI 轮询间隔 / 启动自动连接，全部落盘 */
public class Settings extends Activity {

    EditText sServer, sKey, sRssi, sZero, sSilent, sQuick;
    CheckBox sAuto, sWake;
    TextView sInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("设置");
        setContentView(R.layout.settings);

        sServer = (EditText) findViewById(R.id.s_server);
        sKey = (EditText) findViewById(R.id.s_key);
        sRssi = (EditText) findViewById(R.id.s_rssi);
        sZero = (EditText) findViewById(R.id.s_zero);
        sSilent = (EditText) findViewById(R.id.s_silent);
        sQuick = (EditText) findViewById(R.id.s_quick);
        sAuto = (CheckBox) findViewById(R.id.s_auto);
        sWake = (CheckBox) findViewById(R.id.s_wake);
        sInfo = (TextView) findViewById(R.id.s_info);

        sServer.setText(P.server(this));
        sKey.setText(P.psk(this));
        sRssi.setText(String.valueOf(P.rssiSec(this)));
        int zc = P.zeroChunkMs(this);
        sZero.setText(zc == 0 ? "0" : String.valueOf(zc / 1000.0f));
        sSilent.setText(String.valueOf(P.rssiSilentSec(this)));
        sQuick.setText(P.quickCmdsRaw(this));
        sWake.setChecked(P.keepWake(this));
        sAuto.setChecked(P.autoConnect(this));
        sInfo.setText("当前保存：Server=" + P.server(this)
                + "  RSSI=" + P.rssiSec(this) + "s"
                + "  零片超时=" + (P.zeroChunkMs(this) == 0 ? "关" : P.zeroChunkMs(this) + "ms")
                + "  静默判死=" + (P.rssiSilentSec(this) == 0 ? "关" : P.rssiSilentSec(this) + "s")
                + "  保活=" + P.keepWake(this)
                + "  自动连接=" + P.autoConnect(this)
                + "  密钥=" + (P.psk(this).length() == 0 ? "(空)" : P.psk(this).length() + " 字符"));

        ((Button) findViewById(R.id.s_save)).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { save(); }
        });
        ((Button) findViewById(R.id.s_cancel)).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { finish(); }
        });
    }

    void save() {
        String server = sServer.getText().toString().trim();
        String key = sKey.getText().toString().trim();
        int rssi;
        try {
            rssi = Integer.parseInt(sRssi.getText().toString().trim());
        } catch (NumberFormatException e) {
            Toast.makeText(this, "RSSI 间隔要填 1~60 的数字", Toast.LENGTH_SHORT).show();
            return;
        }
        if (rssi < 1 || rssi > 60) {
            Toast.makeText(this, "RSSI 间隔限制 1~60 秒", Toast.LENGTH_SHORT).show();
            return;
        }
        if (server.length() == 0) {
            Toast.makeText(this, "Server 不能为空", Toast.LENGTH_SHORT).show();
            return;
        }
        // 零片超时：秒（支持小数）→ 毫秒；0 = 关闭提示
        int zeroMs;
        String zs = sZero.getText().toString().trim();
        try {
            double sec = Double.parseDouble(zs);
            zeroMs = (int) Math.round(sec * 1000);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "零片超时要填 0.5~120 的数字（0=关闭）", Toast.LENGTH_SHORT).show();
            return;
        }
        if (zeroMs != 0 && (zeroMs < 500 || zeroMs > 120000)) {
            Toast.makeText(this, "零片超时限制 0.5~120 秒（0=关闭提示）", Toast.LENGTH_SHORT).show();
            return;
        }
        // RSSI 静默判死：秒；0 = 关闭判死
        int silentSec;
        try {
            silentSec = Integer.parseInt(sSilent.getText().toString().trim());
        } catch (NumberFormatException e) {
            Toast.makeText(this, "静默判死要填 5~300 的数字（0=关闭）", Toast.LENGTH_SHORT).show();
            return;
        }
        if (silentSec != 0 && (silentSec < 5 || silentSec > 300)) {
            Toast.makeText(this, "静默判死限制 5~300 秒（0=关闭判死）", Toast.LENGTH_SHORT).show();
            return;
        }
        P.save(this, server, key, sAuto.isChecked(), rssi, zeroMs, silentSec, sWake.isChecked());
        P.saveQuickCmds(this, sQuick.getText().toString());
        sInfo.setText("已保存：" + System.currentTimeMillis() / 1000
                + "\nServer=" + server + "  RSSI=" + rssi + "s"
                + "  零片超时=" + (zeroMs == 0 ? "关" : zeroMs + "ms")
                + "  静默判死=" + (silentSec == 0 ? "关" : silentSec + "s")
                + "  保活=" + sWake.isChecked()
                + "  自动连接=" + sAuto.isChecked()
                + "  密钥=" + (key.length() == 0 ? "(空)" : key.length() + " 字符"));
        Toast.makeText(this, "已保存", Toast.LENGTH_SHORT).show();
    }
}
