package com.myapp.mybleclient;

import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * MyBleClient 命令客户端 —— 界面层。
 *
 * 职责只剩三件事：输入（广播名/密钥/命令）、权限申请、把服务推来的状态画出来。
 * 整条 BLE 连接住在 BleService（前台服务）里：
 *   - 切到别的 app / 回桌面：界面只是 onStop，服务继续跑，通知常驻；
 *   - 从通知栏点回来：singleTop 直接回到本实例，文字原样还在；
 *   - Task 被回收后从通知重建：onCreate 重新 bind，setUi() 整包回放
 *     （状态行/电量信号/按钮/日志），文字立即恢复，绝不会重新发起第二条连接；
 *   - Activity 的 onDestroy 不再碰连接，也就不存在"重复连接"问题。
 */
public class MainActivity extends Activity {

    EditText etServer, etKey, etCmd;
    TextView tvInfo, tvBatt, tvResult;
    ScrollView svResult;
    Button btnConnect;

    BleService svc;                 // 绑定后拿到引擎；为 null 时动作先暂存
    String pendingConnect;          // 服务还没绑上就点了 Connect 时的暂存

    // ------------------------------------------------------------- 服务绑定

    final ServiceConnection conn = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName name, IBinder b) {
            svc = ((BleService.LocalBinder) b).getService();
            svc.setUi(uiCb);        // 重建后重绑：整包回放当前状态，文字即时恢复
            maybeAutoConnect();
            if (pendingConnect != null) {
                String s = pendingConnect;
                pendingConnect = null;
                svc.connect(s);
            }
        }

        @Override public void onServiceDisconnected(ComponentName name) {
            svc = null;             // 只在服务被杀时发生；重连后 binder 会再回调
        }
    };

    /** 服务 → 界面的状态订阅。回调都来自服务主线程，直接操作视图即可 */
    final BleService.Ui uiCb = new BleService.Ui() {
        @Override public void onInfo(String s)      { if (alive()) tvInfo.setText(s); }
        @Override public void onBatt(String s)      { if (alive()) tvBatt.setText(s); }
        @Override public void onLog(String s)       { if (alive()) { tvResult.append(s); scrollDown(); } }
        @Override public void onLogReset(String s)  { if (alive()) { tvResult.setText(s); scrollDown(); } }
        @Override public void onBtn(String t, boolean en) {
            if (alive()) { btnConnect.setText(t); btnConnect.setEnabled(en); }
        }
        @Override public void onToast(String s) {
            if (alive()) Toast.makeText(MainActivity.this, s, Toast.LENGTH_SHORT).show();
        }
    };

    boolean alive() { return !isFinishing() && !isDestroyed(); }

    void scrollDown() {
        svResult.post(new Runnable() {
            @Override public void run() { svResult.fullScroll(View.FOCUS_DOWN); }
        });
    }

    // ---------------------------------------------------------------- 生命周期

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        etServer = (EditText) findViewById(R.id.et_server);
        etKey    = (EditText) findViewById(R.id.et_key);
        etCmd    = (EditText) findViewById(R.id.et_cmd);
        tvInfo   = (TextView) findViewById(R.id.tv_info);
        tvBatt   = (TextView) findViewById(R.id.tv_batt);
        tvResult = (TextView) findViewById(R.id.tv_result);
        svResult = (ScrollView) findViewById(R.id.sv_result);
        btnConnect = (Button) findViewById(R.id.btn_connect);

        // 输入来自持久化设置；APK 内不内置任何密钥
        etServer.setText(P.server(this));
        etKey.setText(P.psk(this));

        btnConnect.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { onConnectClicked(); }
        });
        findViewById(R.id.btn_disconnect).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { userRelease(); }
        });
        findViewById(R.id.btn_run).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { onRunClicked(); }
        });
        findViewById(R.id.btn_quick).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showQuickList(); }
        });
        findViewById(R.id.btn_copy).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { copyResult(); }
        });
        findViewById(R.id.btn_clear).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                tvResult.setText("");
                if (svc != null) svc.clearLog();   // 缓冲不清，重建后又被回放出来
            }
        });

        // bind 即创建服务（空闲时不挂前台通知）。界面怎么重建都不影响引擎，
        // 引擎只在用户点断开或系统杀进程时才停。
        bindService(new Intent(this, BleService.class), conn, Context.BIND_AUTO_CREATE);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);   // singleTop：从通知进来只复用，不新建
    }

    @Override
    protected void onResume() {
        super.onResume();
        maybeAutoConnect();  // 服务已就绪就直接触发；否则等 onServiceConnected 里补
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // 关键：这里只解绑、注销回调，绝不关连接、绝不停服务。
        if (svc != null) svc.clearUi(uiCb);
        svc = null;
        try { unbindService(conn); } catch (Throwable ignored) { }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(0, 1, 0, "设置");
        menu.add(0, 2, 1, "断开并释放");
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == 1) {
            startActivity(new Intent(this, com.myapp.mybleclient.Settings.class));
            return true;
        }
        if (item.getItemId() == 2) {
            userRelease();
            return true;
        }
        return false;
    }

    // ---------------------------------------------------------------- 动作

    void maybeAutoConnect() {
        if (svc != null && P.autoConnect(this)) svc.ensureAutoConnect();
    }

    void onConnectClicked() {
        String want = etServer.getText().toString().trim();
        if (want.length() == 0) { toast("请输入广播名"); return; }
        P.saveServerPsk(this, want, etKey.getText().toString().trim());
        BluetoothManager bm = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        BluetoothAdapter ad = (bm == null) ? null : bm.getAdapter();
        if (ad == null || !ad.isEnabled()) { info("蓝牙未开启，请先打开蓝牙"); return; }
        if (Build.VERSION.SDK_INT >= 23
                && checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION,
                    android.Manifest.permission.ACCESS_COARSE_LOCATION}, 1);
            info("已申请定位权限（BLE 扫描必需），允许后再点 Connect");
            return;
        }
        if (svc != null) svc.connect(want);
        else pendingConnect = want;   // 服务还没绑上（极少见）：先暂存
    }

    void onRunClicked() {
        String c = etCmd.getText().toString().trim();
        if (c.length() == 0) { toast("命令为空"); return; }
        if (svc == null) { toast("引擎未就绪，稍候再试"); return; }
        svc.run(c);                   // 就绪门槛由服务把关，拒绝原因以 toast 回来
    }

    /** 快捷命令：点条目 = 填入输入框并立即发送（命令在设置页维护，一行一条） */
    void showQuickList() {
        final String[] cmds = P.quickCmds(this);
        if (cmds.length == 0) {
            toast("快捷命令为空，去 设置 → 快捷命令 添加（一行一条）");
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("快捷命令（点 = 发送）")
                .setItems(cmds, new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int which) {
                        String c = cmds[which];
                        etCmd.setText(c);
                        etCmd.setSelection(c.length());
                        onRunClicked();
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    /** 手动断开并释放：关链路、撤通知、停服务（与 Activity 生命周期无关） */
    void userRelease() {
        if (svc != null) svc.userRelease();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) {
            info("定位权限已授予，再点一次 Connect");
        }
    }

    // ---------------------------------------------------------------- 显示

    void info(final String s) {
        tvInfo.setText(s);   // 只在主线程被界面自己的流程调用
    }

    void copyResult() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm == null) return;
        cm.setPrimaryClip(ClipData.newPlainText("blecmd", tvResult.getText().toString()));
        toast("已复制");
    }

    void toast(final String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
