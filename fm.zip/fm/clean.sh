rm -rf CMakeFiles
rm -rf Makefile
rm -rf CMakeCache.txt
rm -rf cmake_install.cmake
